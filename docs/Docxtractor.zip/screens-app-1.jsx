/* Dashboard, Extractors list/detail/new, Runs list */

function StatCard({ label, value, icon, accent = '#fff', shadow = '4px 4px 0 0 #000' }) {
  return (
    <div style={{
      background: accent, border: '2px solid #000', boxShadow: shadow,
      padding: '20px 22px', display: 'flex', flexDirection: 'column', gap: 14,
      minHeight: 120,
    }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <span style={{ fontSize: 11, fontWeight: 800, textTransform: 'uppercase', letterSpacing: '0.12em' }}>{label}</span>
        <span className="material-symbols-outlined" style={{ fontSize: 28, opacity: 0.35 }}>{icon}</span>
      </div>
      <div style={{ fontSize: 38, fontWeight: 900, fontStyle: 'italic', letterSpacing: '-0.03em', lineHeight: 1 }}>{value}</div>
    </div>
  );
}

/* ============ DASHBOARD ============ */
function DashboardScreen() {
  return (
    <AppShell active="dashboard">
      <PageHeader heading="Hi, Salman 👋" description="Here's what's happening across your workspace today."
        breadcrumb="/ HOME / DASHBOARD">
        <button className="dx-btn outline"><span className="material-symbols-outlined" style={{ fontSize: 18 }}>upload_file</span>Quick extract</button>
        <button className="dx-btn"><span className="material-symbols-outlined" style={{ fontSize: 18 }}>add</span>New extractor</button>
      </PageHeader>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 18, marginBottom: 28 }}>
        <StatCard label="Documents this month" value="1,284" icon="description" />
        <StatCard label="Successful" value="1,202" icon="check_circle" accent="var(--primary)" />
        <StatCard label="Needs review" value="44" icon="rate_review" accent="#fed7aa" />
        <StatCard label="Failed" value="38" icon="warning" shadow="4px 4px 0 0 var(--accent-red)" />
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1.6fr 1fr', gap: 24 }}>
        {/* Activity */}
        <div className="dx-card" style={{ padding: 0 }}>
          <div style={{ padding: '16px 22px', borderBottom: '2px solid #000', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div style={{ fontWeight: 900, fontSize: 16, textTransform: 'uppercase', letterSpacing: '-0.02em' }}>Recent runs</div>
            <a style={{ fontSize: 11, fontWeight: 800, textTransform: 'uppercase', letterSpacing: '0.1em', textDecoration: 'underline' }}>View all →</a>
          </div>
          {[
            { id: 'd4f1a2e9', name: 'Invoice Auto-Processor', status: 'done', conf: 98, when: '2m ago', docs: 12 },
            { id: '8b1c0f33', name: 'Cash receipts — April', status: 'review', conf: 72, when: '11m ago', docs: 8 },
            { id: 'a90d12bc', name: 'Bank statement parser', status: 'done', conf: 99, when: '38m ago', docs: 24 },
            { id: 'cc40e7d1', name: 'KYC document intake', status: 'failed', conf: null, when: '1h ago', docs: 3 },
            { id: 'f1928aa7', name: 'POS daily sales', status: 'done', conf: 96, when: '2h ago', docs: 31 },
          ].map((r, i) => (
            <div key={r.id} style={{
              display: 'grid', gridTemplateColumns: '110px 1fr 110px 100px 80px',
              alignItems: 'center', gap: 12,
              padding: '14px 22px',
              borderBottom: i < 4 ? '2px solid #000' : 'none',
              fontSize: 13,
            }}>
              <span style={{ fontFamily: 'monospace', fontWeight: 800, fontSize: 12 }}>#{r.id}</span>
              <span style={{ fontWeight: 700 }}>{r.name}</span>
              <span className={`dx-pill ${r.status === 'done' ? 'status-success' : r.status === 'review' ? 'status-paused' : 'status-failed'}`} style={{ justifySelf: 'start' }}>
                <span className="material-symbols-outlined" style={{ fontSize: 12 }}>{r.status === 'done' ? 'check' : r.status === 'review' ? 'rate_review' : 'close'}</span>
                {r.status}
              </span>
              <span style={{ fontFamily: 'monospace', fontWeight: 700, color: r.conf == null ? '#aaa' : r.conf > 90 ? '#10b981' : '#f59e0b' }}>{r.conf == null ? '—' : `${r.conf}%`}</span>
              <span style={{ fontSize: 11, fontWeight: 700, color: '#948a51', textAlign: 'right' }}>{r.when}</span>
            </div>
          ))}
        </div>

        {/* Right column */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
          <div className="dx-card" style={{ padding: '20px 22px' }}>
            <div style={{ fontWeight: 900, fontSize: 14, textTransform: 'uppercase', letterSpacing: '-0.02em', marginBottom: 14 }}>This week</div>
            {/* fake bar chart */}
            <div style={{ display: 'flex', alignItems: 'flex-end', gap: 10, height: 120, padding: '0 4px' }}>
              {[58,72,40,90,65,82,48].map((h,i) => (
                <div key={i} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6 }}>
                  <div style={{ width: '100%', height: `${h}%`, background: i === 3 ? 'var(--primary)' : '#000', border: '2px solid #000' }} />
                  <span style={{ fontSize: 10, fontWeight: 700, color: '#948a51' }}>{['M','T','W','T','F','S','S'][i]}</span>
                </div>
              ))}
            </div>
            <div style={{ marginTop: 12, fontSize: 12, color: '#5a5440' }}><b>+24%</b> vs last week</div>
          </div>

          <div className="dx-card" style={{ padding: 0, background: '#000', color: '#fff', boxShadow: '4px 4px 0 0 var(--primary)' }}>
            <div style={{ padding: '14px 18px', borderBottom: '2px solid var(--primary)', display: 'flex', alignItems: 'center', gap: 10 }}>
              <span className="material-symbols-outlined" style={{ color: 'var(--primary)' }}>auto_awesome</span>
              <span style={{ fontWeight: 900, fontSize: 13, letterSpacing: '0.1em', textTransform: 'uppercase' }}>Suggested for you</span>
            </div>
            <div style={{ padding: '16px 18px' }}>
              <div style={{ fontSize: 14, fontWeight: 700, marginBottom: 6 }}>Build an AutoRun for the “Bank statement parser”</div>
              <div style={{ fontSize: 12, color: '#cfc8a3', marginBottom: 14 }}>You've run it 23 times this month. Schedule it daily and route results to your accounting inbox.</div>
              <button className="dx-btn" style={{ background: 'var(--primary)' }}>Start AutoRun</button>
            </div>
          </div>

          <div className="dx-card" style={{ padding: '18px 22px' }}>
            <div style={{ fontWeight: 900, fontSize: 14, textTransform: 'uppercase', marginBottom: 12 }}>Quick links</div>
            {[
              ['upload_file','Upload a document','Run an extractor on a single file'],
              ['library_books','Template gallery','Pre-built for invoices, KYC, bank statements'],
              ['groups','Invite teammates','3 seats remaining on your plan'],
            ].map(([i,t,s]) => (
              <div key={t} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '10px 0', borderBottom: '1px dashed #d6cfa6' }}>
                <div style={{ width: 36, height: 36, background: 'var(--primary)', border: '2px solid #000', display: 'grid', placeItems: 'center' }}>
                  <span className="material-symbols-outlined" style={{ fontSize: 18 }}>{i}</span>
                </div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 800, fontSize: 13 }}>{t}</div>
                  <div style={{ fontSize: 11, color: '#948a51' }}>{s}</div>
                </div>
                <span className="material-symbols-outlined" style={{ fontSize: 18, color: '#948a51' }}>arrow_forward</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </AppShell>
  );
}

/* ============ EXTRACTORS LIST ============ */
function ExtractorsListScreen() {
  const cards = [
    { name: 'Invoice Auto-Processor', desc: 'Pulls vendor, line items, totals and tax IDs from PDF invoices.', fields: 12, model: 'gpt-4o', updated: '2 hours ago' },
    { name: 'Bank Statement Parser', desc: 'Daily/monthly statement extraction with running balance reconciliation.', fields: 8, model: 'claude-3.5', updated: 'yesterday' },
    { name: 'KYC Document Intake', desc: 'Validates ID, address proof, and signature card alignment.', fields: 15, model: 'gpt-4o', updated: '4 days ago' },
    { name: 'POS Daily Sales', desc: 'Cashier closing reports → consolidated daily revenue rows.', fields: 6, model: 'gpt-4o-mini', updated: 'yesterday' },
    { name: 'Loan Application Forms', desc: 'IDLC application data with field-level confidence tracking.', fields: 22, model: 'claude-3.5', updated: 'last week' },
    { name: 'Cash Receipt Vouchers', desc: 'Manual receipts with handwriting fallback OCR.', fields: 7, model: 'gpt-4o', updated: '3 hours ago' },
    { name: 'Insurance Claim Forms', desc: 'Health & motor insurance claims with attachment review.', fields: 18, model: 'claude-3.5', updated: '5 days ago' },
  ];
  return (
    <AppShell active="extractors">
      <PageHeader heading="My Extractors" description="Manage your extraction workflows. Create, test, and deploy data parsers."
        breadcrumb="/ HOME / EXTRACTORS">
        <button className="dx-btn"><span className="material-symbols-outlined" style={{ fontSize: 18 }}>add</span>New extractor</button>
      </PageHeader>

      {/* search/filter bar */}
      <div className="dx-card" style={{ padding: 14, marginBottom: 22, display: 'flex', gap: 12, alignItems: 'center' }}>
        <div style={{ position: 'relative', flex: 1 }}>
          <span className="material-symbols-outlined" style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', fontSize: 18, color: '#888' }}>search</span>
          <input className="dx-input" style={{ boxShadow: 'inset 3px 3px 6px rgba(0,0,0,0.08)' }} placeholder="Search extractors by name or ID…" />
        </div>
        <button className="dx-btn outline" style={{ padding: '10px 14px' }}>Status: All <span className="material-symbols-outlined" style={{ fontSize: 16 }}>expand_more</span></button>
        <button className="dx-btn outline" style={{ padding: '10px 14px' }}>Owner: Me <span className="material-symbols-outlined" style={{ fontSize: 16 }}>expand_more</span></button>
        <button className="dx-btn outline" style={{ padding: '10px 12px' }}><span className="material-symbols-outlined" style={{ fontSize: 18 }}>sort</span></button>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 20 }}>
        {cards.map((c, i) => (
          <div key={i} className="dx-card" style={{ padding: 0, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
            <div style={{
              height: 120, borderBottom: '2px solid #000',
              background: ['#fef3c7','#cffafe','#fce7f3','#dcfce7','#ede9fe','#fed7aa','#dbeafe'][i % 7],
              position: 'relative', display: 'grid', placeItems: 'center',
            }}>
              <div className="dot-grid-sm" style={{ position: 'absolute', inset: 0, opacity: 0.18 }} />
              <span className="material-symbols-outlined" style={{ fontSize: 56, position: 'relative' }}>
                {['receipt_long','account_balance','badge','point_of_sale','description','payments','health_and_safety'][i % 7]}
              </span>
              <div className="dx-pill status-active" style={{ position: 'absolute', top: 10, right: 10 }}>Active</div>
              <div style={{ position: 'absolute', bottom: 10, left: 10, display: 'flex', gap: 4 }}>
                {['#fda4af','#fde047','#86efac'].map(c => (
                  <div key={c} style={{ width: 8, height: 8, borderRadius: 999, background: c, border: '1px solid #000' }} />
                ))}
              </div>
            </div>
            <div style={{ padding: 16, display: 'flex', flexDirection: 'column', gap: 10, flex: 1 }}>
              <div>
                <div style={{ fontSize: 17, fontWeight: 900, lineHeight: 1.2, letterSpacing: '-0.02em' }}>{c.name}</div>
                <div style={{ fontSize: 10, fontFamily: 'monospace', color: '#948a51', textTransform: 'uppercase', marginTop: 3 }}>{c.updated}</div>
              </div>
              <p style={{ margin: 0, fontSize: 12.5, color: '#5a5440', lineHeight: 1.5 }}>{c.desc}</p>
              <div style={{ marginTop: 'auto', paddingTop: 12, borderTop: '2px dashed #d6cfa6', display: 'flex', justifyContent: 'space-between', fontSize: 11, fontWeight: 800 }}>
                <span style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
                  <span className="material-symbols-outlined" style={{ fontSize: 16 }}>data_object</span>
                  {c.fields} FIELDS
                </span>
                <span style={{ display: 'flex', gap: 6, alignItems: 'center', fontFamily: 'monospace' }}>
                  <span className="material-symbols-outlined" style={{ fontSize: 16 }}>psychology</span>
                  {c.model}
                </span>
              </div>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr auto', borderTop: '2px solid #000' }}>
              <button style={{ padding: '12px 0', borderRight: '2px solid #000', background: '#fff', fontSize: 11, fontWeight: 800, textTransform: 'uppercase', letterSpacing: '0.08em', cursor: 'pointer' }}>
                <span className="material-symbols-outlined" style={{ fontSize: 14, marginRight: 4 }}>edit</span>Edit
              </button>
              <button style={{ padding: '12px 0', borderRight: '2px solid #000', background: 'rgba(229,209,97,0.3)', fontSize: 11, fontWeight: 800, textTransform: 'uppercase', letterSpacing: '0.08em', cursor: 'pointer' }}>
                <span className="material-symbols-outlined" style={{ fontSize: 14, marginRight: 4 }}>play_arrow</span>Run
              </button>
              <button style={{ padding: '12px 16px', background: '#fff', cursor: 'pointer' }}>
                <span className="material-symbols-outlined" style={{ fontSize: 14 }}>delete</span>
              </button>
            </div>
          </div>
        ))}
        {/* placeholder */}
        <div style={{
          background: 'transparent', border: '3px dashed #d6cfa6',
          minHeight: 320, display: 'flex', flexDirection: 'column',
          alignItems: 'center', justifyContent: 'center', gap: 8, cursor: 'pointer',
        }}>
          <div style={{ width: 60, height: 60, borderRadius: 999, background: '#f7f7f5', border: '2px solid #948a51', display: 'grid', placeItems: 'center' }}>
            <span className="material-symbols-outlined" style={{ fontSize: 30, color: '#948a51' }}>add</span>
          </div>
          <div style={{ fontWeight: 900, fontSize: 15, color: '#948a51', textTransform: 'uppercase' }}>Create new extractor</div>
          <div style={{ fontSize: 11.5, color: '#a99e60' }}>Start from scratch or use a template</div>
        </div>
      </div>
    </AppShell>
  );
}

Object.assign(window, { DashboardScreen, ExtractorsListScreen, StatCard });
