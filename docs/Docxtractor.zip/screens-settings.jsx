/* Settings (instance, profile, api-keys), Templates, Demo upload */

function SettingsScreen() {
  const tabs = [
    { k: 'instance', l: 'Instance', ic: 'dns', active: true },
    { k: 'profile', l: 'Profile', ic: 'person' },
    { k: 'api', l: 'API Keys', ic: 'key' },
    { k: 'extraction', l: 'Extraction', ic: 'auto_awesome' },
    { k: 'notif', l: 'Notifications', ic: 'notifications' },
    { k: 'backups', l: 'Backups', ic: 'cloud_sync' },
    { k: 'appearance', l: 'Appearance', ic: 'palette' },
  ];
  return (
    <AppShell active="settings">
      <PageHeader heading="Settings" description="Workspace configuration, API keys, and extraction defaults." breadcrumb="/ HOME / SETTINGS" />
      <div style={{ display: 'grid', gridTemplateColumns: '240px 1fr', gap: 24 }}>
        <div className="dx-card" style={{ padding: 8, alignSelf: 'start' }}>
          {tabs.map(t => (
            <div key={t.k} className={`nav-item ${t.active ? 'active' : ''}`} style={{ marginBottom: 4 }}>
              <span className="material-symbols-outlined" style={{ fontSize: 18 }}>{t.ic}</span>
              {t.l}
            </div>
          ))}
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
          {/* Workspace */}
          <div className="dx-card" style={{ padding: 22 }}>
            <h3 style={{ margin: '0 0 14px', fontSize: 18, fontWeight: 900, fontFamily: 'Archivo Black, sans-serif', letterSpacing: '-0.02em' }}>Workspace</h3>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
              <div>
                <label style={{ fontSize: 11, fontWeight: 800, textTransform: 'uppercase', letterSpacing: '0.08em' }}>Workspace name</label>
                <input className="dx-input" style={{ paddingLeft: 14, marginTop: 6 }} defaultValue="Cefalo" />
              </div>
              <div>
                <label style={{ fontSize: 11, fontWeight: 800, textTransform: 'uppercase', letterSpacing: '0.08em' }}>Default timezone</label>
                <input className="dx-input" style={{ paddingLeft: 14, marginTop: 6 }} defaultValue="Asia/Dhaka" />
              </div>
            </div>
          </div>

          {/* LLM providers */}
          <div className="dx-card" style={{ padding: 22 }}>
            <h3 style={{ margin: '0 0 14px', fontSize: 18, fontWeight: 900, fontFamily: 'Archivo Black, sans-serif', letterSpacing: '-0.02em' }}>LLM Providers</h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {[
                ['OpenAI', 'sk-…7f2A', 'connected', '#dcfce7'],
                ['Anthropic', 'sk-ant-…b91', 'connected', '#dcfce7'],
                ['Local Ollama', 'http://localhost:11434', 'idle', '#fef3c7'],
                ['FreeLLM', 'gateway.freellm.dev', 'connected', '#dcfce7'],
              ].map(([n,key,st,bg]) => (
                <div key={n} style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '12px 14px', border: '2px solid #000', background: '#fff', boxShadow: '3px 3px 0 0 #000' }}>
                  <span className="material-symbols-outlined">psychology</span>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontWeight: 800, fontSize: 13 }}>{n}</div>
                    <div style={{ fontFamily: 'monospace', fontSize: 11, color: '#6b7280' }}>{key}</div>
                  </div>
                  <span style={{ background: bg, border: '2px solid #000', padding: '2px 10px', fontSize: 10, fontWeight: 900, textTransform: 'uppercase' }}>{st}</span>
                  <button className="dx-btn outline" style={{ padding: '6px 12px', fontSize: 11 }}>Edit</button>
                </div>
              ))}
            </div>
            <button className="dx-btn outline" style={{ marginTop: 12, padding: '8px 14px' }}>
              <span className="material-symbols-outlined" style={{ fontSize: 16 }}>add</span>Add provider
            </button>
          </div>

          {/* Storage / Backups */}
          <div className="dx-card" style={{ padding: 22 }}>
            <h3 style={{ margin: '0 0 14px', fontSize: 18, fontWeight: 900, fontFamily: 'Archivo Black, sans-serif', letterSpacing: '-0.02em' }}>Storage & retention</h3>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12 }}>
              {[['384 GB','Used'],['12.4k','Documents'],['90d','Retention']].map(([v,l]) => (
                <div key={l} style={{ padding: 14, border: '2px solid #000', background: '#fafafa', boxShadow: '3px 3px 0 0 #000' }}>
                  <div style={{ fontFamily: 'Archivo Black, sans-serif', fontStyle: 'italic', fontSize: 28, letterSpacing: '-0.02em' }}>{v}</div>
                  <div style={{ fontSize: 10, fontWeight: 800, color: '#6b7280', textTransform: 'uppercase', letterSpacing: '0.1em' }}>{l}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Danger */}
          <div className="dx-card" style={{ padding: 22, borderColor: 'var(--accent-red)', boxShadow: '4px 4px 0 0 var(--accent-red)' }}>
            <h3 style={{ margin: '0 0 4px', fontSize: 18, fontWeight: 900, color: '#b91c1c', fontFamily: 'Archivo Black, sans-serif', letterSpacing: '-0.02em' }}>Danger zone</h3>
            <p style={{ margin: '0 0 14px', fontSize: 12, color: '#6b7280' }}>These actions cannot be undone.</p>
            <div style={{ display: 'flex', gap: 10 }}>
              <button className="dx-btn outline" style={{ borderColor: '#b91c1c', color: '#b91c1c' }}>Reset extractors</button>
              <button className="dx-btn" style={{ background: '#fee2e2', color: '#b91c1c', borderColor: '#b91c1c' }}>Delete workspace</button>
            </div>
          </div>
        </div>
      </div>
    </AppShell>
  );
}

function TemplatesScreen() {
  const tpls = [
    ['Invoice Pro','receipt_long','#fef3c7','Vendor, line items, totals, tax — covers 95% of B2B invoice formats.','12 fields'],
    ['Bank statement','account_balance','#cffafe','Daily transactions with running balance reconciliation.','8 fields'],
    ['KYC packet','badge','#fce7f3','ID, address proof, signature card alignment.','15 fields'],
    ['Insurance claim','health_and_safety','#dbeafe','Health & motor insurance claims with attachment review.','18 fields'],
    ['Loan application','description','#ede9fe','IDLC application data with field-level confidence.','22 fields'],
    ['Receipt OCR','payments','#dcfce7','Manual cash receipts with handwriting fallback.','7 fields'],
  ];
  return (
    <AppShell active="extractors">
      <PageHeader heading="Template gallery" description="Production-tested extraction schemas. Clone, customize, ship."
        breadcrumb="/ HOME / EXTRACTORS / TEMPLATES">
        <button className="dx-btn outline">Browse community →</button>
      </PageHeader>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 18 }}>
        {tpls.map(([n,ic,bg,d,f]) => (
          <div key={n} className="dx-card" style={{ padding: 0, overflow: 'hidden' }}>
            <div style={{ height: 140, background: bg, borderBottom: '2px solid #000', display: 'grid', placeItems: 'center', position: 'relative' }}>
              <span className="material-symbols-outlined" style={{ fontSize: 60 }}>{ic}</span>
              <span className="dx-pill status-success" style={{ position: 'absolute', top: 10, right: 10 }}>Verified</span>
            </div>
            <div style={{ padding: 18 }}>
              <div style={{ fontWeight: 900, fontSize: 17, fontFamily: 'Archivo Black, sans-serif', letterSpacing: '-0.02em' }}>{n}</div>
              <p style={{ margin: '6px 0 14px', fontSize: 12.5, color: '#5a5440', lineHeight: 1.4 }}>{d}</p>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderTop: '2px dashed #d6cfa6', paddingTop: 10 }}>
                <span style={{ fontSize: 11, fontWeight: 800 }}>{f}</span>
                <button className="dx-btn" style={{ padding: '6px 12px', fontSize: 11 }}>Use template</button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </AppShell>
  );
}

window.SettingsScreen = SettingsScreen;
window.TemplatesScreen = TemplatesScreen;
