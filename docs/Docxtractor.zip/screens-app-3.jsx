/* Run detail (split view), Autoruns list, Autoruns new, Autoruns builder, Autoruns runs, Settings, Confirm */

/* ============ RUN DETAIL ============ */
function RunDetailScreen() {
  const fields = [
    { k: 'vendor_name', v: 'Acme Industries Pvt. Ltd.', conf: 99 },
    { k: 'invoice_number', v: 'INV-2025-0421', conf: 100 },
    { k: 'invoice_date', v: '2025-04-21', conf: 100 },
    { k: 'due_date', v: '2025-05-21', conf: 95 },
    { k: 'subtotal', v: '$17,250.00', conf: 98 },
    { k: 'tax_amount', v: '$1,700.00', conf: 96 },
    { k: 'total', v: '$18,950.00', conf: 99 },
    { k: 'currency', v: 'USD', conf: 100 },
    { k: 'tax_id', v: '12-3456789', conf: 87 },
  ];
  return (
    <AppShell active="runs" search={false} fullBleed>
      {/* Top bar */}
      <div style={{
        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
        padding: '14px 32px', borderBottom: '2px solid #000',
        background: '#fffdf2',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
          <button style={{ width: 36, height: 36, background: '#fff', border: '2px solid #000', boxShadow: '2px 2px 0 0 #000', display: 'grid', placeItems: 'center', cursor: 'pointer' }}>
            <span className="material-symbols-outlined" style={{ fontSize: 18 }}>arrow_back</span>
          </button>
          <div>
            <div style={{ fontSize: 11, fontWeight: 800, color: '#948a51', textTransform: 'uppercase', letterSpacing: '0.12em' }}>RUN DETAIL</div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginTop: 2 }}>
              <span style={{ fontFamily: 'monospace', fontWeight: 900, fontSize: 18 }}>#d4f1a2e9</span>
              <span style={{ fontSize: 13, color: '#5a5440' }}>· Invoice Auto-Processor · Apr 21, 14:02</span>
              <span className="dx-pill status-success">Done</span>
            </div>
          </div>
        </div>
        <div style={{ display: 'flex', gap: 10 }}>
          <button className="dx-btn outline" style={{ padding: '8px 14px' }}><span className="material-symbols-outlined" style={{ fontSize: 16 }}>file_download</span>JSON</button>
          <button className="dx-btn outline" style={{ padding: '8px 14px' }}><span className="material-symbols-outlined" style={{ fontSize: 16 }}>table_view</span>CSV</button>
          <button className="dx-btn"><span className="material-symbols-outlined" style={{ fontSize: 16 }}>replay</span>Re-run</button>
        </div>
      </div>

      {/* Two-pane */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', height: 'calc(100% - 75px)' }}>
        {/* Left — document preview */}
        <div style={{ borderRight: '2px solid #000', background: '#1a190e', display: 'flex', flexDirection: 'column' }}>
          <div style={{ padding: '12px 20px', background: '#000', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'space-between', borderBottom: '2px solid var(--primary)' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <span className="material-symbols-outlined" style={{ color: 'var(--primary)' }}>description</span>
              <span style={{ fontFamily: 'monospace', fontSize: 13, fontWeight: 800 }}>acme_invoice_apr21.pdf</span>
              <span style={{ fontSize: 10, fontWeight: 700, color: '#cfc8a3' }}>1 of 1</span>
            </div>
            <div style={{ display: 'flex', gap: 8 }}>
              {['zoom_out','zoom_in','open_in_new'].map(i => (
                <button key={i} style={{ width: 28, height: 28, background: '#222', border: '1px solid #444', color: '#fff', cursor: 'pointer' }}>
                  <span className="material-symbols-outlined" style={{ fontSize: 16, verticalAlign: 'middle' }}>{i}</span>
                </button>
              ))}
            </div>
          </div>
          <div style={{ flex: 1, display: 'grid', placeItems: 'center', padding: 24, overflow: 'auto' }}>
            <div style={{
              width: 480, background: '#fff', border: '3px solid #000',
              boxShadow: '8px 8px 0 0 #ffdd00',
              padding: '32px 36px', position: 'relative',
            }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 20 }}>
                <div>
                  <div style={{ fontSize: 22, fontWeight: 900, letterSpacing: '-0.02em' }}>Acme Industries</div>
                  <div style={{ fontSize: 10, color: '#5a5440', marginTop: 4 }}>1234 Industrial Way · Dhaka 1207</div>
                  <div style={{ fontSize: 10, color: '#5a5440' }}>VAT 12-3456789</div>
                </div>
                <div style={{ textAlign: 'right' }}>
                  <div style={{ fontSize: 9, fontWeight: 800, color: '#948a51', letterSpacing: '0.15em' }}>INVOICE</div>
                  <div style={{ fontFamily: 'monospace', fontWeight: 900, fontSize: 14, marginTop: 4, position: 'relative', display: 'inline-block', background: 'rgba(13,242,242,0.4)', padding: '0 4px', outline: '2px solid #0df2f2', outlineOffset: 2 }}>
                    INV-2025-0421
                  </div>
                  <div style={{ fontSize: 10, marginTop: 6 }}>Date: <span style={{ background: 'rgba(13,242,242,0.4)', outline: '2px solid #0df2f2', outlineOffset: 2, padding: '0 3px' }}>2025-04-21</span></div>
                </div>
              </div>
              <div style={{ height: 2, background: '#000', marginBottom: 14 }} />
              <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 11 }}>
                <thead>
                  <tr><th style={{ textAlign: 'left', padding: '6px 0', borderBottom: '1px solid #000' }}>Item</th><th style={{ textAlign: 'right', borderBottom: '1px solid #000' }}>Qty</th><th style={{ textAlign: 'right', borderBottom: '1px solid #000' }}>Total</th></tr>
                </thead>
                <tbody>
                  {[['Audit retainer','1','12,500.00'],['Compliance review','1','4,800.00'],['Documentation','2','1,200.00'],['Express handling','1','450.00']].map((r,i)=>(
                    <tr key={i}><td style={{ padding: '6px 0', borderBottom: '1px dashed #ccc' }}>{r[0]}</td><td style={{ textAlign: 'right' }}>{r[1]}</td><td style={{ textAlign: 'right', fontFamily: 'monospace' }}>{r[2]}</td></tr>
                  ))}
                </tbody>
              </table>
              <div style={{ marginTop: 14, display: 'flex', justifyContent: 'flex-end', gap: 60 }}>
                <div>
                  <div style={{ fontSize: 10, color: '#5a5440' }}>Subtotal</div>
                  <div style={{ fontSize: 10, color: '#5a5440' }}>Tax (10%)</div>
                  <div style={{ fontSize: 11, fontWeight: 900, marginTop: 2 }}>TOTAL</div>
                </div>
                <div style={{ textAlign: 'right', fontFamily: 'monospace' }}>
                  <div style={{ fontSize: 10 }}>$17,250.00</div>
                  <div style={{ fontSize: 10 }}>$1,700.00</div>
                  <div style={{ fontSize: 13, fontWeight: 900, marginTop: 2, background: 'rgba(229,209,97,0.5)', outline: '2px solid #e5d161', outlineOffset: 2, padding: '0 4px' }}>$18,950.00</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right — extracted data */}
        <div style={{ display: 'flex', flexDirection: 'column', background: '#fffdf2' }}>
          {/* Tabs */}
          <div style={{ display: 'flex', borderBottom: '2px solid #000' }}>
            {['Fields','JSON','Citations','Logs'].map((t,i) => (
              <button key={t} style={{
                padding: '14px 22px',
                background: i === 0 ? 'var(--primary)' : 'transparent',
                border: 'none', borderRight: '2px solid #000',
                borderBottom: i === 0 ? '4px solid #000' : '4px solid transparent',
                fontWeight: 900, fontSize: 12, textTransform: 'uppercase', letterSpacing: '0.08em',
                cursor: 'pointer',
              }}>{t}</button>
            ))}
            <div style={{ flex: 1, borderBottom: '2px solid #000' }} />
          </div>

          {/* Confidence summary */}
          <div style={{ padding: 24, borderBottom: '2px dashed #d6cfa6' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
              <span style={{ fontSize: 11, fontWeight: 800, textTransform: 'uppercase', letterSpacing: '0.1em', color: '#948a51' }}>Overall Confidence</span>
              <span style={{ fontSize: 28, fontFamily: 'Archivo Black, sans-serif', fontStyle: 'italic', letterSpacing: '-0.02em' }}>97.4%</span>
            </div>
            <div style={{ height: 8, background: '#e6e3d1', border: '2px solid #000', position: 'relative', overflow: 'hidden' }}>
              <div style={{ position: 'absolute', inset: 0, width: '97.4%', background: 'var(--accent-cyan)' }} />
            </div>
            <div style={{ marginTop: 8, fontSize: 11, color: '#5a5440' }}>9 fields extracted · 0 needing review · 0 missed</div>
          </div>

          {/* Fields list */}
          <div style={{ flex: 1, overflow: 'auto', padding: 24 }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {fields.map(f => (
                <div key={f.k} style={{
                  background: '#fff', border: '2px solid #000', boxShadow: '4px 4px 0 0 #000',
                  padding: '14px 16px', display: 'grid', gridTemplateColumns: '1fr 1.4fr 70px',
                  gap: 14, alignItems: 'center',
                }}>
                  <div>
                    <div style={{ fontSize: 10, fontWeight: 800, color: '#948a51', textTransform: 'uppercase', letterSpacing: '0.1em' }}>Field</div>
                    <div style={{ fontFamily: 'monospace', fontWeight: 800, fontSize: 13, marginTop: 2 }}>{f.k}</div>
                  </div>
                  <div>
                    <div style={{ fontSize: 10, fontWeight: 800, color: '#948a51', textTransform: 'uppercase', letterSpacing: '0.1em' }}>Value</div>
                    <div style={{ fontWeight: 700, fontSize: 13, marginTop: 2, fontFamily: f.k.includes('amount') || f.k.includes('total') || f.k.includes('subtotal') || f.k === 'tax_id' ? 'monospace' : 'inherit' }}>{f.v}</div>
                  </div>
                  <div style={{ textAlign: 'right' }}>
                    <div style={{
                      display: 'inline-block', padding: '2px 8px', border: '2px solid #000',
                      background: f.conf >= 95 ? '#86efac' : f.conf >= 85 ? '#fde047' : '#fca5a5',
                      fontFamily: 'monospace', fontWeight: 900, fontSize: 12,
                    }}>{f.conf}%</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </AppShell>
  );
}

/* ============ AUTORUNS LIST ============ */
function AutorunsListScreen() {
  const ars = [
    { name: 'Daily invoice ingest', src: 'Email · ap@cefalo.com', sched: 'Every 1h', status: 'active', last: '2m ago', success: 98.2 },
    { name: 'KYC inbox watcher', src: 'Folder · /uploads/kyc', sched: 'Real-time', status: 'active', last: '8m ago', success: 95.6 },
    { name: 'Monthly bank reconciliation', src: 'API · plaid', sched: '1st of month, 09:00', status: 'paused', last: '12d ago', success: 99.8 },
    { name: 'POS daily close', src: 'SFTP · pos.cefalo.net', sched: 'Daily, 23:30', status: 'active', last: '1d ago', success: 96.4 },
    { name: 'Insurance claim queue', src: 'Webhook · claims.api', sched: 'Real-time', status: 'draft', last: '—', success: null },
    { name: 'Loan applications', src: 'Email · loans@idlc.com', sched: 'Every 30m', status: 'active', last: '14m ago', success: 91.0 },
  ];
  return (
    <AppShell active="autoruns">
      <PageHeader heading="AutoRuns" description="Always-on workflows. Connect a source, pick an extractor, ship the data."
        breadcrumb="/ HOME / AUTORUNS">
        <button className="dx-btn outline"><span className="material-symbols-outlined" style={{ fontSize: 18 }}>history</span>Run history</button>
        <button className="dx-btn"><span className="material-symbols-outlined" style={{ fontSize: 18 }}>auto_mode</span>New AutoRun</button>
      </PageHeader>

      {/* Stats */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 18, marginBottom: 24 }}>
        <StatCard label="Active" value="4" icon="bolt" accent="var(--accent-cyan)" />
        <StatCard label="Paused" value="1" icon="pause_circle" accent="#fed7aa" />
        <StatCard label="Drafts" value="1" icon="draft" />
        <StatCard label="Avg success" value="96%" icon="check_circle" accent="var(--primary)" />
      </div>

      {/* Cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 20 }}>
        {ars.map((a,i) => (
          <div key={a.name} className="dx-card" style={{ padding: 0, position: 'relative', boxShadow: '6px 6px 0 0 #000' }}>
            <div style={{
              display: 'flex', justifyContent: 'space-between', alignItems: 'center',
              padding: '14px 20px', borderBottom: '2px solid #000',
              background: a.status === 'active' ? 'rgba(13,242,242,0.2)' : a.status === 'paused' ? '#fed7aa' : '#f3f4f6',
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                <div style={{ width: 8, height: 8, borderRadius: 999, background: a.status === 'active' ? '#10b981' : a.status === 'paused' ? '#f59e0b' : '#6b7280', boxShadow: a.status === 'active' ? '0 0 0 4px rgba(16,185,129,0.25)' : 'none' }} />
                <span className={`dx-pill status-${a.status}`}>{a.status}</span>
              </div>
              <div style={{ display: 'flex', gap: 6 }}>
                {[a.status === 'active' ? 'pause' : 'play_arrow','edit','more_horiz'].map(ic => (
                  <button key={ic} style={{ width: 32, height: 32, background: '#fff', border: '2px solid #000', boxShadow: '2px 2px 0 0 #000', cursor: 'pointer' }}>
                    <span className="material-symbols-outlined" style={{ fontSize: 16 }}>{ic}</span>
                  </button>
                ))}
              </div>
            </div>
            <div style={{ padding: 22 }}>
              <h3 style={{ margin: 0, fontSize: 22, fontWeight: 900, fontFamily: 'Archivo Black, sans-serif', letterSpacing: '-0.02em' }}>{a.name}</h3>
              <div style={{ marginTop: 14, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
                <div style={{ background: '#f7f7f5', border: '2px solid #000', padding: 10 }}>
                  <div style={{ fontSize: 10, fontWeight: 800, color: '#948a51', textTransform: 'uppercase', letterSpacing: '0.1em' }}>Source</div>
                  <div style={{ fontSize: 12, fontWeight: 800, marginTop: 4, fontFamily: 'monospace' }}>{a.src}</div>
                </div>
                <div style={{ background: '#f7f7f5', border: '2px solid #000', padding: 10 }}>
                  <div style={{ fontSize: 10, fontWeight: 800, color: '#948a51', textTransform: 'uppercase', letterSpacing: '0.1em' }}>Schedule</div>
                  <div style={{ fontSize: 12, fontWeight: 800, marginTop: 4 }}>{a.sched}</div>
                </div>
                <div style={{ background: '#f7f7f5', border: '2px solid #000', padding: 10 }}>
                  <div style={{ fontSize: 10, fontWeight: 800, color: '#948a51', textTransform: 'uppercase', letterSpacing: '0.1em' }}>Last run</div>
                  <div style={{ fontSize: 12, fontWeight: 800, marginTop: 4 }}>{a.last}</div>
                </div>
                <div style={{ background: '#f7f7f5', border: '2px solid #000', padding: 10 }}>
                  <div style={{ fontSize: 10, fontWeight: 800, color: '#948a51', textTransform: 'uppercase', letterSpacing: '0.1em' }}>Success rate</div>
                  <div style={{ fontSize: 12, fontWeight: 800, marginTop: 4, fontFamily: 'monospace' }}>{a.success == null ? '—' : `${a.success}%`}</div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </AppShell>
  );
}

/* ============ AUTORUNS NEW (initial form) ============ */
function AutorunsNewScreen() {
  return (
    <AppShell active="autoruns">
      <div style={{ maxWidth: 720, margin: '0 auto' }}>
        <div style={{ marginBottom: 28 }}>
          <div style={{ fontSize: 11, fontWeight: 800, color: '#948a51', textTransform: 'uppercase', letterSpacing: '0.15em', fontFamily: 'monospace', marginBottom: 10 }}>/ AUTORUNS / NEW</div>
          <h1 style={{ margin: 0, fontSize: 42, fontWeight: 900, fontFamily: 'Archivo Black, sans-serif', letterSpacing: '-0.03em', lineHeight: 1 }}>Create an AutoRun</h1>
          <p style={{ marginTop: 12, fontSize: 14, color: '#5a5440', maxWidth: 540 }}>
            Connect a source of new documents, choose how often to check, and pick the extractor that turns each one into structured data.
          </p>
        </div>

        {/* Stepper */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 28 }}>
          {[
            { n: 1, l: 'Basics', active: true },
            { n: 2, l: 'Source' },
            { n: 3, l: 'Extractor' },
            { n: 4, l: 'Destination' },
            { n: 5, l: 'Review' },
          ].map((s, i, arr) => (
            <React.Fragment key={s.n}>
              <div style={{
                display: 'flex', alignItems: 'center', gap: 8,
                padding: '8px 14px',
                border: '2px solid #000',
                background: s.active ? 'var(--primary)' : '#fff',
                boxShadow: s.active ? '4px 4px 0 0 #000' : '2px 2px 0 0 #000',
                fontSize: 12, fontWeight: 800,
              }}>
                <div style={{ width: 22, height: 22, borderRadius: 999, background: s.active ? '#000' : '#f7f7f5', color: s.active ? 'var(--primary)' : '#000', display: 'grid', placeItems: 'center', fontSize: 11, fontWeight: 900, border: '1px solid #000' }}>{s.n}</div>
                {s.l}
              </div>
              {i < arr.length - 1 && <div style={{ flex: 1, height: 2, background: '#000', borderTop: '2px dashed #000', borderBottom: 0 }} />}
            </React.Fragment>
          ))}
        </div>

        <div className="dx-card" style={{ padding: 28, boxShadow: '6px 6px 0 0 #000' }}>
          <h2 style={{ margin: '0 0 18px', fontSize: 22, fontWeight: 900, fontFamily: 'Archivo Black, sans-serif', letterSpacing: '-0.02em' }}>Name your AutoRun</h2>
          <div style={{ marginBottom: 22 }}>
            <label style={{ fontSize: 12, fontWeight: 800, textTransform: 'uppercase', letterSpacing: '0.08em' }}>Name</label>
            <input className="dx-input" style={{ paddingLeft: 14, marginTop: 6 }} defaultValue="Daily invoice ingest" />
          </div>
          <div style={{ marginBottom: 22 }}>
            <label style={{ fontSize: 12, fontWeight: 800, textTransform: 'uppercase', letterSpacing: '0.08em' }}>What does it do?</label>
            <textarea style={{ width: '100%', minHeight: 80, padding: 14, border: '2px solid #000', boxShadow: '4px 4px 0 0 #000', marginTop: 6, fontFamily: 'inherit', fontSize: 13 }}
              defaultValue="Watches the AP inbox for new vendor invoices and routes the extracted line-items to NetSuite." />
          </div>
          <div>
            <label style={{ fontSize: 12, fontWeight: 800, textTransform: 'uppercase', letterSpacing: '0.08em' }}>Tags</label>
            <div style={{ display: 'flex', gap: 8, marginTop: 8, flexWrap: 'wrap' }}>
              {['#ap','#daily','#invoices','#netsuite'].map(t => (
                <span key={t} className="dx-pill status-success" style={{ fontFamily: 'monospace' }}>{t}</span>
              ))}
              <button className="dx-pill" style={{ background: '#fff', borderStyle: 'dashed' }}>+ Add tag</button>
            </div>
          </div>
        </div>

        <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 24 }}>
          <button className="dx-btn ghost">Cancel</button>
          <button className="dx-btn">Continue<span className="material-symbols-outlined">arrow_forward</span></button>
        </div>
      </div>
    </AppShell>
  );
}

/* ============ AUTORUNS BUILDER (step 2 — Source) ============ */
function AutorunsBuilderScreen() {
  const sources = [
    { i: 'mail', l: 'Email', d: 'Forward an inbox to us', selected: true },
    { i: 'folder', l: 'Folder', d: 'Watch a Drive/Dropbox folder' },
    { i: 'webhook', l: 'Webhook', d: 'POST a doc to a URL' },
    { i: 'storage', l: 'Storage', d: 'S3 / GCS bucket' },
    { i: 'api', l: 'API', d: 'Plaid, QuickBooks, Stripe' },
    { i: 'sftp', l: 'SFTP', d: 'Bank file drops' },
  ];
  return (
    <AppShell active="autoruns">
      <div style={{ maxWidth: 1080, margin: '0 auto' }}>
        <div style={{ marginBottom: 24 }}>
          <div style={{ fontSize: 11, fontWeight: 800, color: '#948a51', textTransform: 'uppercase', letterSpacing: '0.15em', fontFamily: 'monospace', marginBottom: 10 }}>/ AUTORUNS / DAILY INVOICE INGEST</div>
          <h1 style={{ margin: 0, fontSize: 38, fontWeight: 900, fontFamily: 'Archivo Black, sans-serif', letterSpacing: '-0.03em' }}>Pick a source</h1>
        </div>

        {/* Stepper compact */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 28, fontSize: 11 }}>
          {['Basics','Source','Extractor','Destination','Review'].map((l, i) => (
            <React.Fragment key={l}>
              <div style={{
                padding: '6px 12px', background: i === 1 ? 'var(--primary)' : i < 1 ? '#000' : '#fff',
                color: i < 1 ? 'var(--primary)' : '#000',
                border: '2px solid #000', fontWeight: 800,
                boxShadow: i === 1 ? '3px 3px 0 0 #000' : 'none',
              }}>
                {i < 1 && <span className="material-symbols-outlined" style={{ fontSize: 14, verticalAlign: -2, marginRight: 4 }}>check</span>}
                {l}
              </div>
              {i < 4 && <div style={{ flex: 1, borderBottom: '2px dashed #000' }} />}
            </React.Fragment>
          ))}
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 360px', gap: 24 }}>
          <div className="dx-card" style={{ padding: 24, boxShadow: '6px 6px 0 0 #000' }}>
            <div style={{ fontWeight: 900, fontSize: 14, textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 14 }}>Source type</div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12, marginBottom: 24 }}>
              {sources.map(s => (
                <div key={s.l} style={{
                  padding: 14, border: '2px solid #000',
                  background: s.selected ? 'var(--primary)' : '#fff',
                  boxShadow: s.selected ? '4px 4px 0 0 #000' : '2px 2px 0 0 #000',
                  cursor: 'pointer',
                }}>
                  <span className="material-symbols-outlined" style={{ fontSize: 26 }}>{s.i}</span>
                  <div style={{ fontWeight: 900, fontSize: 14, marginTop: 6 }}>{s.l}</div>
                  <div style={{ fontSize: 11, color: '#5a5440', marginTop: 2 }}>{s.d}</div>
                </div>
              ))}
            </div>

            {/* Selected config — Email */}
            <div style={{ background: '#f7f7f5', border: '2px solid #000', padding: 20, boxShadow: '4px 4px 0 0 #000' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 16 }}>
                <span className="material-symbols-outlined">mail</span>
                <span style={{ fontWeight: 900, fontSize: 14 }}>Email source</span>
                <span className="dx-pill status-success" style={{ marginLeft: 'auto' }}>Connected</span>
              </div>
              <div style={{ marginBottom: 16 }}>
                <label style={{ fontSize: 11, fontWeight: 800, textTransform: 'uppercase', letterSpacing: '0.08em' }}>Forward to</label>
                <div style={{ marginTop: 6, padding: '12px 14px', background: '#000', color: 'var(--accent-green)', fontFamily: 'monospace', fontSize: 13, fontWeight: 800, border: '2px solid #000', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <span>cefalo-ap@in.docxtractor.com</span>
                  <button style={{ background: 'transparent', border: '1px solid var(--accent-green)', color: 'var(--accent-green)', padding: '2px 8px', fontSize: 10, fontWeight: 800, cursor: 'pointer' }}>COPY</button>
                </div>
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
                <div>
                  <label style={{ fontSize: 11, fontWeight: 800, textTransform: 'uppercase', letterSpacing: '0.08em' }}>Subject filter</label>
                  <input className="dx-input" style={{ paddingLeft: 14, marginTop: 6, height: 38 }} defaultValue="invoice OR receipt" />
                </div>
                <div>
                  <label style={{ fontSize: 11, fontWeight: 800, textTransform: 'uppercase', letterSpacing: '0.08em' }}>Attachment types</label>
                  <input className="dx-input" style={{ paddingLeft: 14, marginTop: 6, height: 38 }} defaultValue=".pdf, .png, .jpg" />
                </div>
              </div>
              <label style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 14, fontSize: 12, fontWeight: 700 }}>
                <input type="checkbox" defaultChecked style={{ accentColor: '#000', width: 16, height: 16 }} />
                Treat the email body as a document too
              </label>
            </div>
          </div>

          {/* Sidebar — schedule preview */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            <div className="dx-card" style={{ padding: 20, boxShadow: '6px 6px 0 0 #000' }}>
              <div style={{ fontWeight: 900, fontSize: 13, textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 12 }}>Schedule</div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, marginBottom: 12 }}>
                {[['Real-time', false],['Every 1h', true],['Daily', false],['Weekly', false]].map(([l,sel]) => (
                  <button key={l} style={{ padding: '10px 0', border: '2px solid #000', background: sel ? 'var(--accent-cyan)' : '#fff', boxShadow: sel ? '3px 3px 0 0 #000' : '1px 1px 0 0 #000', fontSize: 12, fontWeight: 900, cursor: 'pointer' }}>{l}</button>
                ))}
              </div>
              <div style={{ fontSize: 11, color: '#5a5440' }}>Will run at the top of every hour, processing any new attachments.</div>
            </div>
            <div className="dx-card" style={{ padding: 20, background: '#000', color: '#fff', boxShadow: '6px 6px 0 0 var(--primary)' }}>
              <div style={{ fontSize: 11, fontWeight: 800, letterSpacing: '0.15em', color: 'var(--primary)', textTransform: 'uppercase' }}>Tip</div>
              <div style={{ fontSize: 13, marginTop: 8, lineHeight: 1.5 }}>You can route low-confidence runs to a human-review queue in the next step. Helpful for invoices &gt; $5,000.</div>
            </div>
          </div>
        </div>

        <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 24 }}>
          <button className="dx-btn outline"><span className="material-symbols-outlined">arrow_back</span>Back</button>
          <button className="dx-btn">Continue<span className="material-symbols-outlined">arrow_forward</span></button>
        </div>
      </div>
    </AppShell>
  );
}

/* ============ AUTORUNS RUNS (history of one autorun) ============ */
function AutorunsRunsScreen() {
  const runs = Array.from({ length: 12 }).map((_,i) => ({
    id: ['8b1c0f33','d4f1a2e9','f1928aa7','7263abcd','5512cdef','9844eef0','113442aa','22f55b1c','334466dd','445577ee','5566aa00','667711bb'][i],
    when: `Apr ${21 - Math.floor(i/3)}, ${(14 - i).toString().padStart(2,'0')}:0${i % 6}`,
    status: i === 4 ? 'failed' : i === 7 || i === 9 ? 'review' : 'done',
    docs: [12,4,18,6,0,8,9,3,15,7,11,5][i],
    conf: i === 4 ? null : [98,97,96,99,null,95,93,72,99,68,97,94][i],
    dur: `${[14,9,32,11,3,18,21,8,29,12,16,10][i]}s`,
  }));
  return (
    <AppShell active="autoruns" search={false}>
      {/* Hero */}
      <div className="dx-card" style={{ padding: 0, boxShadow: '6px 6px 0 0 #000', marginBottom: 24, overflow: 'hidden' }}>
        <div style={{ padding: '20px 24px', borderBottom: '2px solid #000', background: 'var(--primary)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
            <button style={{ width: 36, height: 36, background: '#fff', border: '2px solid #000', boxShadow: '2px 2px 0 0 #000', display: 'grid', placeItems: 'center', cursor: 'pointer' }}>
              <span className="material-symbols-outlined" style={{ fontSize: 18 }}>arrow_back</span>
            </button>
            <div>
              <div style={{ fontSize: 11, fontWeight: 800, textTransform: 'uppercase', letterSpacing: '0.15em', fontFamily: 'monospace' }}>AUTORUN · #ar_8a1c</div>
              <div style={{ fontSize: 26, fontWeight: 900, fontFamily: 'Archivo Black, sans-serif', letterSpacing: '-0.02em', lineHeight: 1.1, marginTop: 4 }}>Daily invoice ingest</div>
            </div>
          </div>
          <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
            <span className="dx-pill status-active">
              <span className="material-symbols-outlined" style={{ fontSize: 12 }}>bolt</span>
              Active
            </span>
            <button className="dx-btn outline"><span className="material-symbols-outlined" style={{ fontSize: 16 }}>pause</span>Pause</button>
            <button className="dx-btn"><span className="material-symbols-outlined" style={{ fontSize: 16 }}>play_arrow</span>Run now</button>
          </div>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', borderBottom: '2px solid #000' }}>
          {[
            ['Source','mail · ap@cefalo.com'],
            ['Schedule','Every 1h'],
            ['Extractor','Invoice Auto-Processor'],
            ['Destination','NetSuite + Slack'],
          ].map(([k,v], i, arr) => (
            <div key={k} style={{ padding: '14px 20px', borderRight: i < arr.length - 1 ? '2px solid #000' : 'none' }}>
              <div style={{ fontSize: 10, fontWeight: 800, color: '#948a51', textTransform: 'uppercase', letterSpacing: '0.1em' }}>{k}</div>
              <div style={{ fontSize: 13, fontWeight: 800, marginTop: 4, fontFamily: k === 'Source' ? 'monospace' : 'inherit' }}>{v}</div>
            </div>
          ))}
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)' }}>
          {[
            ['Last 24h','142', 'description'],
            ['Successful','138', 'check_circle'],
            ['Needs review','3', 'rate_review'],
            ['Failed','1', 'warning'],
          ].map(([l,v,ic], i, arr) => (
            <div key={l} style={{ padding: '18px 20px', borderRight: i < arr.length - 1 ? '2px solid #000' : 'none', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div>
                <div style={{ fontSize: 10, fontWeight: 800, color: '#948a51', textTransform: 'uppercase', letterSpacing: '0.1em' }}>{l}</div>
                <div style={{ fontFamily: 'Archivo Black, sans-serif', fontStyle: 'italic', fontSize: 30, letterSpacing: '-0.02em', marginTop: 2 }}>{v}</div>
              </div>
              <span className="material-symbols-outlined" style={{ fontSize: 30, color: '#d6cfa6' }}>{ic}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Runs table */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
        <h3 style={{ margin: 0, fontSize: 18, fontWeight: 900, fontFamily: 'Archivo Black, sans-serif' }}>Run history</h3>
        <div style={{ display: 'flex', gap: 8 }}>
          <button className="dx-btn outline" style={{ padding: '6px 12px', fontSize: 11 }}>Last 24h <span className="material-symbols-outlined" style={{ fontSize: 14 }}>expand_more</span></button>
          <button className="dx-btn outline" style={{ padding: '6px 12px', fontSize: 11 }}>All status <span className="material-symbols-outlined" style={{ fontSize: 14 }}>expand_more</span></button>
          <button className="dx-btn outline" style={{ padding: '6px 12px', fontSize: 11 }}><span className="material-symbols-outlined" style={{ fontSize: 14 }}>file_download</span> Export</button>
        </div>
      </div>

      <div className="dx-card" style={{ padding: 0, overflow: 'hidden' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
          <thead>
            <tr style={{ background: '#f7f7f5', borderBottom: '3px solid #000' }}>
              {['Run ID','Triggered at','Docs','Status','Confidence','Duration','Actions'].map(h => (
                <th key={h} style={{ padding: '12px 18px', textAlign: 'left', fontSize: 11, fontWeight: 900, textTransform: 'uppercase', letterSpacing: '0.1em' }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {runs.map((r,i) => (
              <tr key={r.id + i} style={{ borderBottom: i < runs.length - 1 ? '2px solid #f0ecd4' : 'none' }}>
                <td style={{ padding: '11px 18px', fontFamily: 'monospace', fontWeight: 800, textDecoration: 'underline' }}>#{r.id}</td>
                <td style={{ padding: '11px 18px', color: '#5a5440', fontWeight: 700 }}>{r.when}</td>
                <td style={{ padding: '11px 18px', fontFamily: 'monospace', fontWeight: 800 }}>{r.docs}</td>
                <td style={{ padding: '11px 18px' }}><span className={`dx-pill ${r.status === 'done' ? 'status-success' : r.status === 'review' ? 'status-paused' : 'status-failed'}`}>{r.status}</span></td>
                <td style={{ padding: '11px 18px', fontFamily: 'monospace', fontWeight: 800, color: r.conf == null ? '#aaa' : r.conf > 90 ? '#10b981' : '#f59e0b' }}>{r.conf == null ? '—' : `${r.conf}%`}</td>
                <td style={{ padding: '11px 18px', fontFamily: 'monospace' }}>{r.dur}</td>
                <td style={{ padding: '11px 18px' }}>
                  <button className="dx-btn outline" style={{ padding: '4px 10px', fontSize: 10 }}>Open</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </AppShell>
  );
}

Object.assign(window, { RunDetailScreen, AutorunsListScreen, AutorunsNewScreen, AutorunsBuilderScreen, AutorunsRunsScreen });
