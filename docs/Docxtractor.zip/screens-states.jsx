/* State screens — loading, empty, error, success — for core flows */

/* ============ EXTRACTORS — EMPTY STATE ============ */
function ExtractorsEmptyScreen() {
  return (
    <AppShell active="extractors">
      <PageHeader heading="My Extractors" description="Manage your extraction workflows." breadcrumb="/ HOME / EXTRACTORS">
        <button className="dx-btn"><span className="material-symbols-outlined" style={{ fontSize: 18 }}>add</span>New extractor</button>
      </PageHeader>
      <div style={{
        background: '#fff', border: '3px dashed #000',
        padding: '72px 32px', textAlign: 'center',
      }}>
        <div style={{
          width: 96, height: 96, margin: '0 auto 24px',
          background: 'var(--primary)', border: '3px solid #000',
          boxShadow: '6px 6px 0 0 #000',
          display: 'grid', placeItems: 'center',
        }}>
          <span className="material-symbols-outlined" style={{ fontSize: 56 }}>data_object</span>
        </div>
        <h2 style={{ margin: 0, fontSize: 30, fontWeight: 900, fontFamily: 'Archivo Black, sans-serif', letterSpacing: '-0.02em' }}>No extractors yet</h2>
        <p style={{ marginTop: 12, fontSize: 14, color: '#6b7280', maxWidth: 460, margin: '12px auto 0' }}>
          An extractor is a reusable schema that turns documents into structured data. Start from a template or build your own from scratch.
        </p>
        <div style={{ marginTop: 32, display: 'flex', justifyContent: 'center', gap: 12 }}>
          <button className="dx-btn"><span className="material-symbols-outlined" style={{ fontSize: 18 }}>add</span>Create extractor</button>
          <button className="dx-btn outline"><span className="material-symbols-outlined" style={{ fontSize: 18 }}>library_books</span>Browse templates</button>
        </div>
        <div style={{ marginTop: 40, display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12, maxWidth: 720, margin: '40px auto 0' }}>
          {[
            ['receipt_long','Invoices','12 fields'],
            ['account_balance','Bank statements','8 fields'],
            ['badge','KYC forms','15 fields'],
          ].map(([ic,l,d]) => (
            <div key={l} style={{ padding: 14, border: '2px solid #000', background: '#fff', boxShadow: '3px 3px 0 0 #000', cursor: 'pointer', textAlign: 'left' }}>
              <span className="material-symbols-outlined" style={{ fontSize: 24 }}>{ic}</span>
              <div style={{ fontWeight: 900, fontSize: 13, marginTop: 6 }}>{l}</div>
              <div style={{ fontSize: 11, color: '#6b7280' }}>{d}</div>
            </div>
          ))}
        </div>
      </div>
    </AppShell>
  );
}

/* ============ RUN — LOADING / IN-PROGRESS ============ */
function RunLoadingScreen() {
  return (
    <AppShell active="runs" search={false}>
      <div style={{ maxWidth: 720, margin: '40px auto 0' }}>
        <div className="dx-card" style={{ padding: 0, boxShadow: '8px 8px 0 0 #000', overflow: 'hidden' }}>
          <div style={{ padding: '14px 20px', background: 'var(--primary)', borderBottom: '3px solid #000', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <div style={{
                width: 18, height: 18, border: '3px solid #000',
                borderTopColor: 'transparent', borderRadius: 999,
                animation: 'spin 0.8s linear infinite',
              }} />
              <span className="dx-pill status-running">Running</span>
              <span style={{ fontFamily: 'monospace', fontWeight: 800, fontSize: 13 }}>#d4f1a2e9</span>
            </div>
            <button className="dx-btn outline" style={{ padding: '6px 12px', fontSize: 11 }}>
              <span className="material-symbols-outlined" style={{ fontSize: 14 }}>cancel</span>Cancel
            </button>
          </div>

          <div style={{ padding: 32 }}>
            <div style={{ fontSize: 11, fontWeight: 800, color: '#6b7280', textTransform: 'uppercase', letterSpacing: '0.12em' }}>EXTRACTING</div>
            <h2 style={{ margin: '8px 0 24px', fontSize: 30, fontWeight: 900, fontFamily: 'Archivo Black, sans-serif', letterSpacing: '-0.03em' }}>
              acme_invoice_apr21.pdf
            </h2>

            {/* Progress bar */}
            <div style={{ marginBottom: 8, display: 'flex', justifyContent: 'space-between', fontSize: 12, fontWeight: 800 }}>
              <span>3 of 5 stages</span>
              <span style={{ fontFamily: 'monospace' }}>62%</span>
            </div>
            <div style={{ height: 14, background: '#fff', border: '2px solid #000', position: 'relative', overflow: 'hidden' }}>
              <div style={{ position: 'absolute', inset: 0, width: '62%', background: 'var(--primary)', borderRight: '2px solid #000' }} />
              <div style={{ position: 'absolute', inset: 0, backgroundImage: 'repeating-linear-gradient(45deg, transparent, transparent 6px, rgba(0,0,0,0.1) 6px, rgba(0,0,0,0.1) 12px)', animation: 'shift 1s linear infinite' }} />
            </div>
            <style>{`@keyframes shift { to { background-position: 12px 0; } } @keyframes spin { to { transform: rotate(360deg); } }`}</style>

            {/* Steps */}
            <div style={{ marginTop: 32, display: 'flex', flexDirection: 'column', gap: 10 }}>
              {[
                ['Uploading file', 'done', '0.4s'],
                ['Document classification', 'done', '1.2s'],
                ['OCR + layout parse', 'done', '3.8s'],
                ['Field extraction (consensus)', 'running', '— in progress'],
                ['Validation & confidence scoring', 'pending', '—'],
              ].map(([l, st, t]) => (
                <div key={l} style={{
                  display: 'flex', alignItems: 'center', gap: 14,
                  padding: '12px 16px', border: '2px solid #000',
                  background: st === 'running' ? 'rgba(253,224,71,0.3)' : st === 'done' ? '#fff' : '#f3f4f6',
                  boxShadow: st === 'running' ? '4px 4px 0 0 #000' : '2px 2px 0 0 #000',
                }}>
                  <div style={{ width: 24, height: 24, border: '2px solid #000', borderRadius: 999, display: 'grid', placeItems: 'center', background: st === 'done' ? '#86efac' : st === 'running' ? '#fde047' : '#fff' }}>
                    {st === 'done' && <span className="material-symbols-outlined" style={{ fontSize: 14 }}>check</span>}
                    {st === 'running' && <div style={{ width: 8, height: 8, borderRadius: 999, background: '#000', animation: 'pulse 1s infinite' }} />}
                  </div>
                  <span style={{ fontWeight: 700, fontSize: 13, flex: 1 }}>{l}</span>
                  <span style={{ fontFamily: 'monospace', fontSize: 11, color: '#6b7280', fontWeight: 700 }}>{t}</span>
                </div>
              ))}
            </div>
            <style>{`@keyframes pulse { 50% { opacity: 0.3; } }`}</style>

            {/* Live log */}
            <div style={{ marginTop: 24, background: '#000', color: '#4ade80', padding: 14, fontFamily: 'monospace', fontSize: 11, border: '2px solid #000' }}>
              <div style={{ color: '#9ca3af' }}>[14:02:11] doc.parse: 3 pages detected</div>
              <div style={{ color: '#9ca3af' }}>[14:02:13] ocr: 1,284 tokens · confidence 99.1%</div>
              <div>[14:02:15] consensus: model_a → vendor_name = "Acme Industries..."</div>
              <div>[14:02:15] consensus: model_b → vendor_name = "Acme Industries..."</div>
              <div style={{ color: '#fde047' }}>[14:02:16] extracting line_items[3/4]<span style={{ animation: 'blink 1s steps(1) infinite' }}>▋</span></div>
            </div>
            <style>{`@keyframes blink { 50% { opacity: 0; } }`}</style>
          </div>
        </div>
      </div>
    </AppShell>
  );
}

/* ============ RUN — ERROR STATE ============ */
function RunErrorScreen() {
  return (
    <AppShell active="runs" search={false}>
      <div style={{ maxWidth: 720, margin: '40px auto 0' }}>
        <div className="dx-card" style={{ padding: 0, boxShadow: '8px 8px 0 0 var(--accent-red)', overflow: 'hidden', borderColor: '#000' }}>
          <div style={{ padding: '14px 20px', background: 'var(--accent-red)', color: '#fff', borderBottom: '3px solid #000', display: 'flex', alignItems: 'center', gap: 12 }}>
            <span className="material-symbols-outlined">error</span>
            <span style={{ fontWeight: 900, textTransform: 'uppercase', letterSpacing: '0.1em', fontSize: 13 }}>Extraction failed</span>
            <span style={{ fontFamily: 'monospace', fontSize: 12, marginLeft: 'auto' }}>#cc40e7d1 · Apr 21 12:48</span>
          </div>

          <div style={{ padding: 32 }}>
            <div style={{ fontSize: 11, fontWeight: 800, color: '#6b7280', textTransform: 'uppercase', letterSpacing: '0.12em' }}>SOURCE</div>
            <h2 style={{ margin: '8px 0 4px', fontSize: 26, fontWeight: 900, fontFamily: 'Archivo Black, sans-serif', letterSpacing: '-0.02em' }}>kyc_packet_3742.pdf</h2>
            <div style={{ fontSize: 12, color: '#6b7280' }}>KYC document intake · 14.2 MB · 28 pages</div>

            <div style={{
              marginTop: 24, padding: 18,
              background: '#fef2f2', border: '2px solid #000',
              boxShadow: '4px 4px 0 0 #000',
            }}>
              <div style={{ fontSize: 11, fontWeight: 900, color: '#b91c1c', textTransform: 'uppercase', letterSpacing: '0.1em', marginBottom: 8 }}>
                Error · OCR_TIMEOUT
              </div>
              <div style={{ fontSize: 14, fontWeight: 600, color: '#111' }}>
                Document OCR exceeded the 60s timeout. The file appears to contain scanned images at high resolution that couldn't be processed in a single pass.
              </div>
              <div style={{ marginTop: 14, fontFamily: 'monospace', fontSize: 11, padding: 10, background: '#000', color: '#fca5a5', maxHeight: 100, overflow: 'auto' }}>
                at OCREngine.process (ocr/engine.ts:142:18)<br/>
                at ExtractionPipeline.run (pipeline.ts:78:11)<br/>
                at async runExtractor (run.service.ts:204:5)
              </div>
            </div>

            <div style={{ marginTop: 24 }}>
              <div style={{ fontSize: 12, fontWeight: 900, textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 12 }}>
                Suggested fixes
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                {[
                  ['split','Split into smaller chunks','Process pages 1–10 first, then continue.'],
                  ['hd','Lower OCR resolution','Use 150 DPI instead of 300 DPI for this run.'],
                  ['schedule','Retry with extended timeout','Run with OCR_TIMEOUT=180s.'],
                ].map(([ic,t,d]) => (
                  <div key={t} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: 14, background: '#fff', border: '2px solid #000', boxShadow: '3px 3px 0 0 #000' }}>
                    <span className="material-symbols-outlined">{ic}</span>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontWeight: 800, fontSize: 13 }}>{t}</div>
                      <div style={{ fontSize: 11, color: '#6b7280' }}>{d}</div>
                    </div>
                    <button className="dx-btn outline" style={{ padding: '6px 12px', fontSize: 11 }}>Apply</button>
                  </div>
                ))}
              </div>
            </div>

            <div style={{ marginTop: 24, display: 'flex', gap: 12 }}>
              <button className="dx-btn"><span className="material-symbols-outlined" style={{ fontSize: 18 }}>replay</span>Retry run</button>
              <button className="dx-btn outline"><span className="material-symbols-outlined" style={{ fontSize: 18 }}>support_agent</span>Contact support</button>
              <button className="dx-btn ghost" style={{ marginLeft: 'auto' }}>View logs →</button>
            </div>
          </div>
        </div>
      </div>
    </AppShell>
  );
}

/* ============ RUN — SUCCESS / TOAST + SUMMARY ============ */
function RunSuccessScreen() {
  return (
    <AppShell active="runs" search={false}>
      <div style={{ maxWidth: 760, margin: '40px auto 0' }}>
        <div className="dx-card" style={{ padding: 0, boxShadow: '8px 8px 0 0 #000', overflow: 'hidden' }}>
          <div style={{ padding: '32px 32px 28px', background: 'linear-gradient(180deg, #ecfdf5 0%, #fff 100%)', borderBottom: '3px solid #000', textAlign: 'center', position: 'relative' }}>
            <div style={{
              width: 88, height: 88, margin: '0 auto 16px',
              background: '#86efac', border: '3px solid #000',
              boxShadow: '6px 6px 0 0 #000', borderRadius: 999,
              display: 'grid', placeItems: 'center',
              animation: 'pop 0.4s cubic-bezier(0.34, 1.56, 0.64, 1)',
            }}>
              <span className="material-symbols-outlined" style={{ fontSize: 56, fontWeight: 900 }}>check</span>
            </div>
            <style>{`@keyframes pop { 0% { transform: scale(0); } 70% { transform: scale(1.1); } 100% { transform: scale(1); } }`}</style>
            <h1 style={{ margin: 0, fontSize: 36, fontWeight: 900, fontFamily: 'Archivo Black, sans-serif', letterSpacing: '-0.03em' }}>
              Extraction complete
            </h1>
            <p style={{ margin: '10px 0 0', fontSize: 15, color: '#374151' }}>
              acme_invoice_apr21.pdf · 9 fields · 5.4s
            </p>
            <span className="dx-pill status-success" style={{ marginTop: 14 }}>
              <span className="material-symbols-outlined" style={{ fontSize: 12 }}>verified</span>
              97.4% confidence
            </span>
          </div>

          <div style={{ padding: 28 }}>
            <div style={{ fontSize: 11, fontWeight: 900, textTransform: 'uppercase', letterSpacing: '0.12em', marginBottom: 12 }}>Extracted preview</div>
            <div style={{ background: '#000', color: '#4ade80', padding: 16, fontFamily: 'monospace', fontSize: 12, lineHeight: 1.7, border: '2px solid #000' }}>
              <div><span style={{ color: '#9ca3af' }}>{`{`}</span></div>
              <div>  "vendor": <span style={{ color: '#fde047' }}>"Acme Industries Pvt. Ltd."</span>,</div>
              <div>  "invoice_number": <span style={{ color: '#fde047' }}>"INV-2025-0421"</span>,</div>
              <div>  "total": <span style={{ color: '#fde047' }}>18950.00</span>,</div>
              <div>  "currency": <span style={{ color: '#fde047' }}>"USD"</span>,</div>
              <div>  "line_items": <span style={{ color: '#fde047' }}>[ 4 rows ]</span></div>
              <div><span style={{ color: '#9ca3af' }}>{`}`}</span></div>
            </div>

            <div style={{ marginTop: 22, display: 'flex', gap: 12 }}>
              <button className="dx-btn"><span className="material-symbols-outlined" style={{ fontSize: 18 }}>visibility</span>Open run</button>
              <button className="dx-btn outline"><span className="material-symbols-outlined" style={{ fontSize: 18 }}>file_download</span>Download JSON</button>
              <button className="dx-btn outline"><span className="material-symbols-outlined" style={{ fontSize: 18 }}>send</span>Send to NetSuite</button>
            </div>

            <div style={{ marginTop: 22, padding: 14, background: '#fffbeb', border: '2px dashed #000', display: 'flex', alignItems: 'center', gap: 12 }}>
              <span className="material-symbols-outlined">auto_awesome</span>
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 800, fontSize: 13 }}>Want this on autopilot?</div>
                <div style={{ fontSize: 11, color: '#6b7280' }}>You've run this extractor 23 times this month. Schedule it as an AutoRun.</div>
              </div>
              <button className="dx-btn" style={{ padding: '6px 12px', fontSize: 11 }}>Set up AutoRun</button>
            </div>
          </div>
        </div>
      </div>
    </AppShell>
  );
}

/* ============ RUNS — EMPTY (no runs yet) ============ */
function RunsEmptyScreen() {
  return (
    <AppShell active="runs">
      <PageHeader heading="Extraction Runs" description="Monitor and manage your AI extraction extractors." breadcrumb="/ HOME / RUNS">
        <button className="dx-btn"><span className="material-symbols-outlined" style={{ fontSize: 18 }}>add_circle</span>New run</button>
      </PageHeader>
      <div style={{ background: '#fff', border: '3px solid #000', padding: '80px 32px', textAlign: 'center', boxShadow: '8px 8px 0 0 #000' }}>
        <div style={{
          width: 120, height: 120, margin: '0 auto 24px',
          background: '#fff', border: '3px solid #000', boxShadow: '6px 6px 0 0 #000',
          display: 'grid', placeItems: 'center', position: 'relative',
        }}>
          <span className="material-symbols-outlined" style={{ fontSize: 64 }}>history</span>
          <span className="material-symbols-outlined" style={{ position: 'absolute', top: -14, right: -14, background: 'var(--primary)', border: '3px solid #000', padding: 4, fontSize: 22 }}>add</span>
        </div>
        <h2 style={{ margin: 0, fontSize: 28, fontWeight: 900, fontFamily: 'Archivo Black, sans-serif', letterSpacing: '-0.02em' }}>No runs yet</h2>
        <p style={{ marginTop: 10, fontSize: 14, color: '#6b7280', maxWidth: 460, margin: '10px auto 0' }}>
          Drag a document anywhere on this page or pick an extractor below to start your first run.
        </p>
        <div style={{ marginTop: 32, padding: '40px 24px', background: '#fffbeb', border: '3px dashed #000', maxWidth: 480, margin: '32px auto 0' }}>
          <span className="material-symbols-outlined" style={{ fontSize: 40 }}>cloud_upload</span>
          <div style={{ fontWeight: 900, fontSize: 14, marginTop: 8 }}>Drop a PDF here</div>
          <div style={{ fontSize: 11, color: '#6b7280' }}>Or click to browse · max 50MB</div>
        </div>
      </div>
    </AppShell>
  );
}

/* ============ DOC-UPLOAD — DRAG/UPLOADING ============ */
function UploadingScreen() {
  return (
    <AppShell active="runs" search={false}>
      <div style={{ maxWidth: 720, margin: '40px auto 0' }}>
        <h1 style={{ margin: 0, fontSize: 32, fontWeight: 900, fontFamily: 'Archivo Black, sans-serif', letterSpacing: '-0.03em' }}>New Run</h1>
        <p style={{ marginTop: 8, fontSize: 14, color: '#6b7280' }}>Drop your documents below — extraction starts as soon as upload finishes.</p>

        <div style={{
          marginTop: 24, padding: '60px 32px',
          background: 'rgba(253,224,71,0.2)', border: '3px dashed #000',
          textAlign: 'center', position: 'relative', overflow: 'hidden',
        }}>
          <div style={{ position: 'absolute', inset: 0, backgroundImage: 'repeating-linear-gradient(45deg, transparent, transparent 12px, rgba(0,0,0,0.04) 12px, rgba(0,0,0,0.04) 24px)' }} />
          <div style={{ position: 'relative' }}>
            <span className="material-symbols-outlined" style={{ fontSize: 56 }}>cloud_upload</span>
            <div style={{ fontWeight: 900, fontSize: 18, marginTop: 8 }}>Release to upload 3 files</div>
            <div style={{ fontSize: 12, color: '#374151', marginTop: 4 }}>PDF, PNG, JPG · up to 50MB each</div>
          </div>
        </div>

        <div style={{ marginTop: 24, display: 'flex', flexDirection: 'column', gap: 10 }}>
          {[
            { n: 'invoice_apr_21.pdf', pct: 100, status: 'done' },
            { n: 'receipts_batch.pdf', pct: 64, status: 'uploading' },
            { n: 'expense_summary.pdf', pct: 12, status: 'uploading' },
          ].map(f => (
            <div key={f.n} className="dx-card" style={{ padding: 14, display: 'flex', alignItems: 'center', gap: 14 }}>
              <span className="material-symbols-outlined" style={{ fontSize: 28 }}>description</span>
              <div style={{ flex: 1 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
                  <span style={{ fontWeight: 800, fontSize: 13 }}>{f.n}</span>
                  <span style={{ fontFamily: 'monospace', fontSize: 11, fontWeight: 800 }}>{f.pct}%</span>
                </div>
                <div style={{ height: 8, background: '#fff', border: '2px solid #000' }}>
                  <div style={{ width: `${f.pct}%`, height: '100%', background: f.status === 'done' ? '#86efac' : 'var(--primary)' }} />
                </div>
              </div>
              <button style={{ width: 30, height: 30, background: '#fff', border: '2px solid #000', cursor: 'pointer' }}>
                <span className="material-symbols-outlined" style={{ fontSize: 16 }}>close</span>
              </button>
            </div>
          ))}
        </div>
      </div>
    </AppShell>
  );
}

Object.assign(window, { ExtractorsEmptyScreen, RunLoadingScreen, RunErrorScreen, RunSuccessScreen, RunsEmptyScreen, UploadingScreen });
