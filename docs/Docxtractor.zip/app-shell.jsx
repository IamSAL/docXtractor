/* Shared AppLayout — sidebar + topbar shell that wraps every authenticated screen.
   Mirrors client/src/components/AppLayout in the live app. */

const { useState } = React;

function Sidebar({ active }) {
  const items = [
    { key: 'dashboard', label: 'Dashboard', icon: 'space_dashboard', to: '/dashboard' },
    { key: 'extractors', label: 'Extractors', icon: 'data_object', to: '/extractors' },
    { key: 'autoruns', label: 'AutoRuns', icon: 'auto_mode', to: '/autoruns' },
    { key: 'runs', label: 'Runs', icon: 'history', to: '/runs' },
    { key: 'settings', label: 'Settings', icon: 'settings', to: '/settings' },
  ];
  return (
    <aside style={{
      width: 248, flexShrink: 0,
      background: '#fffdf2',
      borderRight: '2px solid #000',
      display: 'flex', flexDirection: 'column',
      padding: '20px 14px',
      gap: 4,
    }}>
      {/* Logo */}
      <div style={{
        display: 'flex', alignItems: 'center', gap: 10,
        padding: '8px 8px 18px', marginBottom: 12,
        borderBottom: '2px dashed #d6cfa6',
      }}>
        <div style={{
          width: 38, height: 38,
          background: 'var(--primary)',
          border: '2px solid #000',
          boxShadow: '2px 2px 0 0 #000',
          display: 'grid', placeItems: 'center',
          fontWeight: 900, fontSize: 18, fontStyle: 'italic',
        }}>D</div>
        <div>
          <div style={{ fontWeight: 900, fontSize: 17, letterSpacing: '-0.02em', lineHeight: 1 }}>
            docXtractor
          </div>
          <div style={{ fontSize: 10, fontWeight: 700, color: '#948a51', textTransform: 'uppercase', letterSpacing: '0.15em', marginTop: 2 }}>
            v1.0
          </div>
        </div>
      </div>

      {items.map(it => (
        <div key={it.key} className={`nav-item ${active === it.key ? 'active' : ''}`}>
          <span className="material-symbols-outlined" style={{ fontSize: 20 }}>{it.icon}</span>
          <span>{it.label}</span>
        </div>
      ))}

      <div style={{ flex: 1 }} />

      {/* Plan card */}
      <div style={{
        background: '#000', color: '#fff',
        border: '2px solid #000',
        padding: '14px 14px',
        boxShadow: '4px 4px 0 0 var(--primary)',
      }}>
        <div style={{ fontSize: 10, fontWeight: 800, letterSpacing: '0.15em', color: 'var(--primary)' }}>FREE PLAN</div>
        <div style={{ fontSize: 13, fontWeight: 700, marginTop: 4 }}>62 / 100 runs used</div>
        <div style={{ height: 6, background: '#333', marginTop: 8, border: '1px solid var(--primary)' }}>
          <div style={{ height: '100%', width: '62%', background: 'var(--primary)' }} />
        </div>
        <button style={{
          marginTop: 10, width: '100%',
          background: 'var(--primary)', color: '#000',
          border: '2px solid var(--primary)',
          fontSize: 11, fontWeight: 900, padding: '6px 0',
          textTransform: 'uppercase', letterSpacing: '0.1em',
          cursor: 'pointer',
        }}>Upgrade →</button>
      </div>

      {/* User */}
      <div style={{
        marginTop: 12,
        display: 'flex', alignItems: 'center', gap: 10,
        padding: '10px 8px',
        borderTop: '2px dashed #d6cfa6',
      }}>
        <div style={{
          width: 34, height: 34, borderRadius: 999,
          background: '#0df2f2', border: '2px solid #000',
          display: 'grid', placeItems: 'center',
          fontWeight: 900, fontSize: 13,
        }}>SA</div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontWeight: 800, fontSize: 13, lineHeight: 1.2 }}>Salman Ahmed</div>
          <div style={{ fontSize: 11, color: '#948a51', fontWeight: 600 }}>salman@cefalo.com</div>
        </div>
        <span className="material-symbols-outlined" style={{ fontSize: 18, color: '#948a51' }}>more_vert</span>
      </div>
    </aside>
  );
}

function TopBar({ search = true }) {
  return (
    <div style={{
      height: 60, flexShrink: 0,
      borderBottom: '2px solid #000',
      background: '#fffdf2',
      display: 'flex', alignItems: 'center',
      padding: '0 24px',
      gap: 16,
    }}>
      {search && (
        <div style={{ position: 'relative', width: 360 }}>
          <span className="material-symbols-outlined" style={{
            position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)',
            fontSize: 18, color: '#888',
          }}>search</span>
          <input className="dx-input" style={{ height: 40, boxShadow: '2px 2px 0 0 #000' }}
            placeholder="Search extractors, runs, docs…" />
          <kbd style={{
            position: 'absolute', right: 10, top: '50%', transform: 'translateY(-50%)',
            background: '#f3eecc', border: '1px solid #000', padding: '1px 6px',
            fontSize: 10, fontWeight: 800,
          }}>⌘K</kbd>
        </div>
      )}
      <div style={{ flex: 1 }} />
      <button className="dx-btn outline" style={{ padding: '8px 14px' }}>
        <span className="material-symbols-outlined" style={{ fontSize: 18 }}>help</span>
        Docs
      </button>
      <div style={{
        position: 'relative',
        width: 40, height: 40,
        background: '#fff', border: '2px solid #000',
        boxShadow: '2px 2px 0 0 #000',
        display: 'grid', placeItems: 'center',
        cursor: 'pointer',
      }}>
        <span className="material-symbols-outlined" style={{ fontSize: 20 }}>notifications</span>
        <div style={{
          position: 'absolute', top: -6, right: -6,
          width: 18, height: 18, borderRadius: 999,
          background: 'var(--accent-red)', color: '#fff',
          border: '2px solid #000',
          fontSize: 9, fontWeight: 900,
          display: 'grid', placeItems: 'center',
        }}>3</div>
      </div>
    </div>
  );
}

function PageHeader({ heading, description, breadcrumb, children }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between',
      gap: 24, paddingBottom: 24, marginBottom: 28,
      borderBottom: '4px solid #000',
    }}>
      <div>
        {breadcrumb && (
          <div style={{
            fontSize: 11, fontWeight: 800, color: '#948a51',
            textTransform: 'uppercase', letterSpacing: '0.15em',
            marginBottom: 10, fontFamily: 'monospace',
          }}>{breadcrumb}</div>
        )}
        <h1 style={{
          margin: 0, fontSize: 38, fontWeight: 900, lineHeight: 1,
          letterSpacing: '-0.03em',
          fontFamily: 'Archivo Black, Archivo, sans-serif',
        }}>{heading}</h1>
        {description && (
          <p style={{ margin: '10px 0 0', fontSize: 14, color: '#5a5440', maxWidth: 560 }}>{description}</p>
        )}
      </div>
      <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap', justifyContent: 'flex-end' }}>{children}</div>
    </div>
  );
}

function AppShell({ active, children, search = true, fullBleed = false }) {
  return (
    <div style={{
      display: 'flex',
      width: 1440, height: 900,
      background: 'var(--bg-cream)',
      overflow: 'hidden',
      fontSize: 14,
    }}>
      <Sidebar active={active} />
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0 }}>
        <TopBar search={search} />
        <div style={{ flex: 1, overflow: 'auto', padding: fullBleed ? 0 : '32px 36px' }}>
          {children}
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { AppShell, Sidebar, TopBar, PageHeader });
