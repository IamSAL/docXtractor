/* Landing — stage branch faithful: white bg dot grid, GitHub focus, marquee, no fake bank logos */

function ScrollSpan({ children, delay = 0 }) {
  return <div style={{ animation: `fadeUp 0.6s ease-out ${delay}s both` }}>{children}</div>;
}

function LandingScreen() {
  return (
    <div style={{
      width: 1440, minHeight: 900,
      backgroundImage: 'radial-gradient(#d4d4d4 1.5px, transparent 1.5px)',
      backgroundSize: '24px 24px',
      backgroundColor: '#fff',
      fontFamily: 'Space Grotesk, Inter, sans-serif',
      color: '#000',
      paddingBottom: 0,
    }}>
      <style>{`
        @keyframes fadeUp { from { opacity: 0; transform: translate3d(0, 30px, 0); } to { opacity: 1; transform: translate3d(0,0,0); } }
        @keyframes spin { to { transform: rotate(360deg); } }
        @keyframes scrollMarquee { from { transform: translateX(0); } to { transform: translateX(-50%); } }
      `}</style>

      {/* Nav */}
      <nav style={{
        position: 'sticky', top: 0, zIndex: 50, background: '#fff',
        borderBottom: '4px solid #000', padding: '12px 24px',
      }}>
        <div style={{ maxWidth: 1280, margin: '0 auto', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <div style={{ background: '#000', color: '#fff', padding: 4 }}>
              <span className="material-symbols-outlined" style={{ fontSize: 22, fontWeight: 800 }}>grid_view</span>
            </div>
            <h1 style={{ margin: 0, fontSize: 20, fontWeight: 800, letterSpacing: '-0.01em', textTransform: 'uppercase' }}>DocXTractor</h1>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 20 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontWeight: 800, fontSize: 13 }}>
              <span style={{ width: 18, height: 18, borderRadius: 999, background: '#000', display: 'inline-block' }} />
              GitHub
            </div>
            <button style={{
              background: 'var(--primary)', border: '3px solid #000',
              padding: '8px 20px', fontWeight: 800, fontSize: 13,
              textTransform: 'uppercase', boxShadow: '6px 6px 0 0 #000',
              cursor: 'pointer',
            }}>Launch App</button>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section style={{ padding: '64px 24px', borderBottom: '4px solid #000' }}>
        <div style={{ maxWidth: 1280, margin: '0 auto', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 32, alignItems: 'center' }}>
          <ScrollSpan>
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-start', gap: 20 }}>
              <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8, border: '2px solid #000', background: '#fff', padding: '4px 12px', borderRadius: 999 }}>
                <span style={{ width: 8, height: 8, borderRadius: 999, background: '#22c55e' }} />
                <span style={{ fontWeight: 800, fontSize: 11, textTransform: 'uppercase', letterSpacing: '0.15em' }}>System Operational</span>
              </div>
              <h1 style={{ margin: 0, fontSize: 60, fontWeight: 900, lineHeight: 0.95, letterSpacing: '-0.04em', textTransform: 'uppercase' }}>
                Documents In.<br/>
                <span style={{ background: 'linear-gradient(to right, #000, #6b7280)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>Data Out.</span><br/>
                Automatically.
              </h1>
              <p style={{ margin: 0, fontSize: 19, fontWeight: 500, maxWidth: 460, color: '#374151' }}>
                Industrial-strength document extraction. Turn messy PDFs into clean JSON in seconds.
              </p>
              <div style={{ display: 'flex', gap: 16 }}>
                <button style={{
                  background: 'var(--primary)', border: '3px solid #000',
                  padding: '14px 24px', fontSize: 15, fontWeight: 900,
                  textTransform: 'uppercase', boxShadow: '6px 6px 0 0 #000', cursor: 'pointer',
                }}>Start Extracting</button>
                <button style={{
                  background: '#fff', border: '3px solid #000',
                  padding: '14px 24px', fontSize: 15, fontWeight: 800,
                  textTransform: 'uppercase', cursor: 'pointer',
                }}>View Demo</button>
              </div>
            </div>
          </ScrollSpan>

          <ScrollSpan delay={0.2}>
            <div style={{ position: 'relative' }}>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 16, alignItems: 'center', position: 'relative', zIndex: 10 }}>
                <div style={{ background: '#fff', border: '3px solid #000', padding: 16, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 12, boxShadow: '8px 8px 0 0 rgba(0,0,0,0.1)' }}>
                  <span className="material-symbols-outlined" style={{ fontSize: 38 }}>description</span>
                  <span style={{ fontFamily: 'monospace', fontSize: 10, fontWeight: 800, background: '#000', color: '#fff', padding: '0 4px' }}>INVOICE.PDF</span>
                </div>
                <div style={{ background: '#000', color: '#fff', border: '3px solid #000', borderRadius: 999, width: 80, height: 80, margin: '0 auto', display: 'grid', placeItems: 'center', position: 'relative', zIndex: 20 }}>
                  <span className="material-symbols-outlined" style={{ fontSize: 32, animation: 'spin 4s linear infinite' }}>settings</span>
                </div>
                <div style={{ background: '#fff', border: '3px solid #000', padding: 16, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 12, boxShadow: '8px 8px 0 0 rgba(0,0,0,0.1)' }}>
                  <span className="material-symbols-outlined" style={{ fontSize: 38, color: 'var(--primary)' }}>data_object</span>
                  <span style={{ fontFamily: 'monospace', fontSize: 10, fontWeight: 800, background: 'var(--primary)', color: '#000', padding: '0 4px' }}>DATA.JSON</span>
                </div>
              </div>
              <div style={{ marginTop: 32, background: '#000', padding: 16, border: '3px solid #000', boxShadow: '8px 8px 0 0 #000', maxWidth: 380, marginLeft: 'auto', marginRight: 'auto', transform: 'rotate(1deg)' }}>
                <div style={{ display: 'flex', gap: 6, marginBottom: 8, paddingBottom: 8, borderBottom: '1px solid #444' }}>
                  <div style={{ width: 8, height: 8, borderRadius: 999, background: '#ef4444' }} />
                  <div style={{ width: 8, height: 8, borderRadius: 999, background: '#eab308' }} />
                  <div style={{ width: 8, height: 8, borderRadius: 999, background: '#22c55e' }} />
                </div>
                <div style={{ fontFamily: 'monospace', fontSize: 11, color: '#4ade80' }}>
                  <div>&gt; docker run -p 8000:8000 docxtractor/core</div>
                  <div style={{ color: '#fff', marginTop: 4 }}>Starting local extraction engine...</div>
                  <div style={{ marginTop: 4 }}><span style={{ color: '#fde047' }}>✓</span> Ready on port 8000</div>
                </div>
              </div>
            </div>
          </ScrollSpan>
        </div>
      </section>

      {/* Open source */}
      <section style={{ background: '#fff', padding: '60px 24px', borderBottom: '4px solid #000' }}>
        <div style={{ maxWidth: 1280, margin: '0 auto' }}>
          <h2 style={{ margin: 0, fontSize: 44, fontWeight: 900, textTransform: 'uppercase', letterSpacing: '-0.03em', textAlign: 'center', marginBottom: 40, lineHeight: 1.05 }}>
            Your Data, Your Rules:<br/>Open Source Freedom
          </h2>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 28 }}>
            {[
              { ic: 'terminal', bg: 'var(--primary)', t: 'Completely Open Source', d: "No black boxes. DocXTractor's core is open source, allowing full auditability, community contributions, and infinite customization to fit your enterprise needs.", items: ['Self-Hostable On-Premise','MIT Licensed Engine','No Vendor Lock-in'] },
              { ic: 'shield_person', bg: '#000', color: '#fff', t: 'Private & Compliant', d: 'Maintain 100% data sovereignty. Run state-of-the-art extraction on your own hardware, ensuring sensitive documents never leave your secure environment.', items: ['Cloud AI with FreeLLM','Full Data Compliance','Air-Gapped Ready'] },
            ].map(c => (
              <div key={c.t} style={{ padding: 32, background: '#fff', border: '3px solid #000', boxShadow: '6px 6px 0 0 #000' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginBottom: 16 }}>
                  <span className="material-symbols-outlined" style={{ fontSize: 38, background: c.bg, color: c.color || '#000', padding: 8, border: '2px solid #000' }}>{c.ic}</span>
                  <h3 style={{ margin: 0, fontSize: 22, fontWeight: 900, textTransform: 'uppercase' }}>{c.t}</h3>
                </div>
                <p style={{ margin: 0, fontSize: 17, fontWeight: 500, color: '#4b5563', lineHeight: 1.3 }}>{c.d}</p>
                <ul style={{ marginTop: 24, padding: 0, listStyle: 'none', display: 'flex', flexDirection: 'column', gap: 12 }}>
                  {c.items.map(it => (
                    <li key={it} style={{ display: 'flex', alignItems: 'center', gap: 8, fontWeight: 700 }}>
                      <span className="material-symbols-outlined" style={{ color: '#16a34a' }}>check_circle</span>{it}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Marquee */}
      <div style={{ borderBottom: '4px solid #000', background: '#fff', padding: '32px 0', overflow: 'hidden' }}>
        <div style={{ display: 'flex', gap: 64, fontWeight: 800, textTransform: 'uppercase', fontSize: 18, letterSpacing: '0.15em', opacity: 0.6, animation: 'scrollMarquee 20s linear infinite', whiteSpace: 'nowrap' }}>
          {Array.from({ length: 2 }).map((_,k) => (
            <div key={k} style={{ display: 'flex', gap: 64, flexShrink: 0 }}>
              {['TRICKLE.IO','SUDO TECH','TRIANGLE SYSTEMS','SHIELD LOGISTICS','GLOBAL CORE','JSON-GEN','TRICKLE.IO','SUDO TECH','TRIANGLE SYSTEMS'].map((s,i) => (
                <span key={i}>{s}</span>
              ))}
            </div>
          ))}
        </div>
      </div>

      {/* Stats */}
      <section style={{ padding: '60px 24px', borderBottom: '4px solid #000', background: '#fff' }}>
        <div style={{ maxWidth: 1280, margin: '0 auto', display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', textAlign: 'center' }}>
          {[['99.9%','Accuracy Rate'],['250M+','Docs Processed'],['<2s','Avg Latency']].map(([n,l],i,arr) => (
            <div key={l} style={{ padding: 16, borderRight: i < arr.length - 1 ? '1px solid rgba(0,0,0,0.1)' : 'none', display: 'flex', flexDirection: 'column', gap: 8 }}>
              <div style={{ fontSize: 60, fontWeight: 900, letterSpacing: '-0.04em' }}>{n}</div>
              <span style={{ fontSize: 13, fontWeight: 800, letterSpacing: '0.15em', textTransform: 'uppercase', background: 'var(--primary)', display: 'inline-block', padding: '0 8px', alignSelf: 'center' }}>{l}</span>
            </div>
          ))}
        </div>
      </section>

      {/* Footer */}
      <footer style={{ background: '#fff', padding: '40px 24px', borderTop: '4px solid #000' }}>
        <div style={{ maxWidth: 1280, margin: '0 auto', display: 'flex', justifyContent: 'space-between', gap: 48 }}>
          <div style={{ maxWidth: 280, display: 'flex', flexDirection: 'column', gap: 16 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <div style={{ background: '#000', color: '#fff', padding: 4 }}>
                <span className="material-symbols-outlined" style={{ fontSize: 20 }}>grid_view</span>
              </div>
              <h1 style={{ margin: 0, fontSize: 20, fontWeight: 800, textTransform: 'uppercase' }}>DocXTractor</h1>
            </div>
            <p style={{ margin: 0, fontSize: 13, fontWeight: 500, color: '#6b7280' }}>The new standard for industrial document processing. Minimalist, fast, and developer-friendly.</p>
            <p style={{ margin: 0, fontSize: 11, fontWeight: 800, textTransform: 'uppercase' }}>© 2025 DocXTractor</p>
          </div>
          <div style={{ display: 'flex', gap: 96 }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              <h4 style={{ margin: 0, fontWeight: 900, fontSize: 13, textTransform: 'uppercase', letterSpacing: '0.1em', borderBottom: '2px solid var(--primary)', alignSelf: 'flex-start' }}>Project</h4>
              {['GitHub','Issues','Changelog'].map(l => (
                <a key={l} style={{ fontSize: 13, fontWeight: 700, color: '#000' }}>{l}</a>
              ))}
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              <h4 style={{ margin: 0, fontWeight: 900, fontSize: 13, textTransform: 'uppercase', letterSpacing: '0.1em', borderBottom: '2px solid var(--primary)', alignSelf: 'flex-start' }}>Resources</h4>
              {['Documentation','API Reference','Community'].map(l => (
                <a key={l} style={{ fontSize: 13, fontWeight: 700, color: '#000' }}>{l}</a>
              ))}
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

window.LandingScreen = LandingScreen;
