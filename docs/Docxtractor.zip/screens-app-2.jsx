/* Extractor detail, new/edit form, Runs list, Run detail */

/* ============ EXTRACTOR DETAIL ============ */
function ExtractorDetailScreen() {
  const fields = [
    { name: 'vendor_name', type: 'string', req: true },
    { name: 'invoice_number', type: 'string', req: true },
    { name: 'invoice_date', type: 'date', req: true },
    { name: 'due_date', type: 'date', req: false },
    { name: 'subtotal', type: 'number', req: true },
    { name: 'tax_amount', type: 'number', req: false },
    { name: 'total', type: 'number', req: true },
    { name: 'currency', type: 'string', req: true },
    { name: 'tax_id', type: 'string', req: false },
    { name: 'line_items', type: 'array', req: true },
  ];
  return (
    <AppShell active="extractors">
      {/* Sticky header */}
      <div style={{
        margin: '-32px -36px 28px', padding: '14px 36px',
        borderBottom: '4px solid #000',
        background: '#fffdf2',
        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
          <button style={{ width: 36, height: 36, background: '#fff', border: '2px solid #000', boxShadow: '2px 2px 0 0 #000', display: 'grid', placeItems: 'center', cursor: 'pointer' }}>
            <span className="material-symbols-outlined" style={{ fontSize: 18 }}>arrow_back</span>
          </button>
          <h2 style={{ margin: 0, fontSize: 22, fontWeight: 900, letterSpacing: '-0.02em' }}>Invoice Auto-Processor</h2>
          <span className="dx-pill status-active">Active</span>
        </div>
        <div style={{ display: 'flex', gap: 10 }}>
          <button className="dx-btn outline" style={{ padding: '8px 14px' }}><span className="material-symbols-outlined" style={{ fontSize: 16 }}>edit</span>Edit</button>
        </div>
      </div>

      {/* Hero card */}
      <div className="dx-card" style={{ padding: 32, boxShadow: '8px 8px 0 0 #000', position: 'relative', overflow: 'hidden', marginBottom: 24, display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: 36 }}>
        <div style={{ position: 'absolute', top: -100, right: -80, width: 280, height: 280, borderRadius: 999, background: 'var(--primary)', opacity: 0.25, filter: 'blur(40px)', pointerEvents: 'none' }} />
        <div style={{ position: 'relative' }}>
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 16 }}>
            <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6, padding: '4px 10px', background: '#fff', border: '1px solid #000', borderRadius: 999, fontSize: 11, fontWeight: 800, textTransform: 'uppercase' }}>
              <span className="material-symbols-outlined" style={{ fontSize: 14 }}>folder_open</span>Extractor
            </span>
            <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6, padding: '4px 10px', background: '#dbeafe', border: '1px solid #000', borderRadius: 999, fontSize: 11, fontWeight: 800, textTransform: 'uppercase', boxShadow: '2px 2px 0 0 #000' }}>
              <span className="material-symbols-outlined fill" style={{ fontSize: 14 }}>verified</span>Consensus
            </span>
            <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6, padding: '4px 10px', background: '#ede9fe', border: '1px solid #000', borderRadius: 999, fontSize: 11, fontWeight: 800, textTransform: 'uppercase' }}>
              <span className="material-symbols-outlined" style={{ fontSize: 14 }}>psychology</span>gpt-4o
            </span>
          </div>
          <h2 style={{ margin: 0, fontSize: 38, fontWeight: 900, letterSpacing: '-0.03em', lineHeight: 1.05 }}>Invoice Auto-Processor</h2>
          <p style={{ marginTop: 14, marginBottom: 22, fontSize: 16, color: '#1a190e', maxWidth: 480, lineHeight: 1.4, fontWeight: 500 }}>
            Pulls vendor, line items, totals and tax IDs from PDF invoices. Tested across 1,200+ vendor formats with 99.4% field accuracy.
          </p>
          <div style={{ display: 'flex', gap: 14, alignItems: 'center', flexWrap: 'wrap' }}>
            <button className="dx-btn" style={{ padding: '14px 22px', fontSize: 14, boxShadow: '6px 6px 0 0 #000' }}>
              <span className="material-symbols-outlined">rocket_launch</span>Run extractor
            </button>
            <button className="dx-btn outline" style={{ padding: '12px 18px' }}>
              <span className="material-symbols-outlined" style={{ fontSize: 16 }}>history</span>Run history
            </button>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 12, color: '#5a5440', fontFamily: 'monospace', marginLeft: 8 }}>
              <div style={{ width: 8, height: 8, borderRadius: 999, background: '#22c55e' }} />
              Ready to process
            </div>
          </div>
        </div>
        <div style={{
          aspectRatio: '4/3',
          background: 'linear-gradient(160deg, #1f2937, #111827)',
          border: '4px solid #000', boxShadow: '8px 8px 0 0 #000',
          position: 'relative', display: 'grid', placeItems: 'center', overflow: 'hidden',
        }}>
          <span className="material-symbols-outlined" style={{ fontSize: 96, color: '#374151' }}>description</span>
          <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(to top, rgba(0,0,0,0.85), transparent)' }} />
          <div style={{ position: 'absolute', bottom: 14, left: 14, padding: '6px 12px', background: '#fff', border: '2px solid #000', boxShadow: '4px 4px 0 0 #000', fontSize: 11, fontWeight: 900, textTransform: 'uppercase' }}>
            Sample preview
          </div>
        </div>
      </div>

      {/* 3-col */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 24 }}>
        {/* Schema */}
        <div className="dx-card" style={{ padding: 22, boxShadow: '8px 8px 0 0 #000' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', paddingBottom: 14, borderBottom: '4px solid #000', marginBottom: 14 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, fontWeight: 900, fontSize: 18 }}>
              <span className="material-symbols-outlined" style={{ fontSize: 24 }}>schema</span>Schema
            </div>
            <span style={{ background: '#000', color: '#fff', padding: '4px 10px', fontSize: 10, fontWeight: 800, borderRadius: 999 }}>{fields.length} Fields</span>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {fields.slice(0,8).map(f => (
              <div key={f.name} style={{
                display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                padding: '10px 12px', background: '#f7f7f5', border: '2px solid #000',
                boxShadow: '3px 3px 0 0 #cccccc',
              }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                  <span className="material-symbols-outlined" style={{ fontSize: 20, color: '#5a5440' }}>
                    {f.type === 'string' ? 'abc' : f.type === 'number' ? 'attach_money' : f.type === 'date' ? 'calendar_today' : 'data_array'}
                  </span>
                  <div>
                    <div style={{ fontWeight: 800, fontSize: 13 }}>{f.name}</div>
                    <div style={{ fontSize: 9, fontFamily: 'monospace', color: '#948a51', textTransform: 'uppercase' }}>{f.type}</div>
                  </div>
                </div>
                {f.req
                  ? <span style={{ fontSize: 9, fontWeight: 900, background: '#fee2e2', color: '#b91c1c', padding: '2px 6px', border: '2px solid #fecaca' }}>REQ</span>
                  : <span style={{ fontSize: 9, fontWeight: 900, background: '#dbeafe', color: '#1d4ed8', padding: '2px 6px', border: '2px solid #bfdbfe' }}>OPT</span>}
              </div>
            ))}
            <div style={{ textAlign: 'center', fontSize: 11, fontWeight: 700, color: '#948a51', marginTop: 4 }}>+ 2 more fields</div>
          </div>
        </div>

        {/* Logic & limits */}
        <div className="dx-card" style={{ padding: 22, boxShadow: '8px 8px 0 0 #000' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, fontWeight: 900, fontSize: 18, paddingBottom: 14, borderBottom: '4px solid #000', marginBottom: 14 }}>
            <span className="material-symbols-outlined" style={{ fontSize: 24 }}>psychology</span>Logic & Limits
          </div>
          <div style={{ background: '#f5f3ff', border: '2px solid #000', padding: 16, position: 'relative', boxShadow: '4px 4px 0 0 #000', marginBottom: 16 }}>
            <span style={{ position: 'absolute', top: -10, right: -6, background: 'var(--primary)', color: '#000', fontSize: 10, fontWeight: 900, padding: '3px 8px', border: '2px solid #000', textTransform: 'uppercase', letterSpacing: '0.1em' }}>Active strategy</span>
            <div style={{ fontWeight: 900, fontSize: 14, marginBottom: 12, display: 'flex', alignItems: 'center', gap: 8 }}>
              <span className="material-symbols-outlined" style={{ color: '#7c3aed' }}>how_to_vote</span>Consensus Voting
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
              <div style={{ background: '#fff', border: '2px solid #c4b5fd', padding: 10 }}>
                <div style={{ fontSize: 9, fontWeight: 800, color: '#948a51', textTransform: 'uppercase' }}>Threshold</div>
                <div style={{ fontFamily: 'Archivo Black, sans-serif', fontSize: 24, fontWeight: 900 }}>85%</div>
              </div>
              <div style={{ background: '#fff', border: '2px solid #c4b5fd', padding: 10 }}>
                <div style={{ fontSize: 9, fontWeight: 800, color: '#948a51', textTransform: 'uppercase' }}>Method</div>
                <div style={{ fontFamily: 'Archivo Black, sans-serif', fontSize: 16, fontWeight: 900 }}>Majority</div>
              </div>
            </div>
          </div>
          <div style={{ background: '#fff', border: '2px solid #000', padding: 14, boxShadow: '4px 4px 0 0 #000' }}>
            <div style={{ fontWeight: 900, fontSize: 13, marginBottom: 10, display: 'flex', alignItems: 'center', gap: 8 }}>
              <span className="material-symbols-outlined" style={{ fontSize: 18 }}>settings</span>Configuration
            </div>
            {[
              ['Model', 'gpt-4o', '#ede9fe'],
              ['Citations', 'ENABLED', '#dcfce7'],
              ['Context', '128k tokens', '#dbeafe'],
            ].map(([k,v,bg]) => (
              <div key={k} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '8px 10px', background: '#f7f7f5', border: '1px solid #000', marginBottom: 6 }}>
                <span style={{ fontSize: 12, fontWeight: 800 }}>{k}</span>
                <span style={{ fontSize: 10, fontWeight: 800, background: bg, padding: '2px 8px', border: '1px solid #000', fontFamily: 'monospace' }}>{v}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Management */}
        <div className="dx-card" style={{ padding: 22, boxShadow: '8px 8px 0 0 #000' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, fontWeight: 900, fontSize: 18, paddingBottom: 14, borderBottom: '4px solid #000', marginBottom: 14 }}>
            <span className="material-symbols-outlined" style={{ fontSize: 24 }}>admin_panel_settings</span>Management
          </div>
          <button className="dx-btn" style={{ width: '100%', justifyContent: 'center', padding: '14px 0', fontSize: 14, marginBottom: 18, boxShadow: '6px 6px 0 0 #000' }}>
            <span className="material-symbols-outlined">edit_square</span>Edit extractor
          </button>
          <div style={{ background: '#f7f7f5', border: '2px solid #000', padding: 14, boxShadow: '4px 4px 0 0 #000', marginBottom: 14 }}>
            {[
              ['Last modified', '2 hours ago'],
              ['Created', '4 months ago'],
              ['ID', 'd4f1a2e9'],
            ].map(([k,v], i, arr) => (
              <div key={k} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '8px 0', borderBottom: i < arr.length-1 ? '2px dashed #d6cfa6' : 'none' }}>
                <span style={{ fontSize: 11, fontWeight: 800, color: '#948a51', textTransform: 'uppercase' }}>{k}</span>
                <span style={{ fontSize: 12, fontWeight: 800, fontFamily: k === 'ID' ? 'monospace' : 'inherit', background: k === 'ID' ? '#e5e7eb' : 'transparent', padding: k === 'ID' ? '2px 6px' : 0, border: k === 'ID' ? '1px solid #000' : 'none' }}>{v}</span>
              </div>
            ))}
          </div>
          <div style={{ background: '#f7f7f5', border: '2px solid #000', padding: 14, boxShadow: '4px 4px 0 0 #000', marginBottom: 16 }}>
            <div style={{ fontSize: 11, fontWeight: 800, color: '#948a51', textTransform: 'uppercase', marginBottom: 10 }}>Quick actions</div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
              {[['content_copy','Duplicate'],['share','Share']].map(([i,l]) => (
                <button key={l} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', padding: 10, background: '#fff', border: '2px solid #000', cursor: 'pointer', gap: 4 }}>
                  <span className="material-symbols-outlined" style={{ fontSize: 22 }}>{i}</span>
                  <span style={{ fontSize: 11, fontWeight: 800 }}>{l}</span>
                </button>
              ))}
            </div>
          </div>
          <button style={{ width: '100%', display: 'flex', justifyContent: 'center', alignItems: 'center', gap: 8, padding: '12px 0', borderTop: '4px solid #000', background: 'transparent', color: '#dc2626', fontWeight: 900, fontSize: 12, textTransform: 'uppercase', letterSpacing: '0.1em', cursor: 'pointer' }}>
            <span className="material-symbols-outlined">delete_forever</span>Delete extractor
          </button>
        </div>
      </div>
    </AppShell>
  );
}

/* ============ NEW / EDIT EXTRACTOR ============ */
function ExtractorFormScreen() {
  return (
    <AppShell active="extractors">
      <div style={{
        margin: '-32px -36px 28px', padding: '18px 36px',
        borderBottom: '2px solid #000', background: '#fffdf2',
        display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end',
      }}>
        <div>
          <h2 style={{ margin: 0, fontSize: 30, fontWeight: 900, letterSpacing: '-0.03em', fontFamily: 'Archivo Black, sans-serif' }}>New Invoice Extractor</h2>
          <div style={{ fontSize: 13, color: '#5a5440', marginTop: 6, display: 'flex', alignItems: 'center', gap: 6 }}>
            <span className="material-symbols-outlined" style={{ fontSize: 16 }}>add_circle</span>
            Create a new extraction extractor
          </div>
        </div>
        <div style={{ display: 'flex', gap: 12 }}>
          <button className="dx-btn ghost" style={{ color: '#dc2626' }}>Cancel</button>
          <button className="dx-btn outline"><span className="material-symbols-outlined fill" style={{ fontSize: 16 }}>play_arrow</span>Test run</button>
          <button className="dx-btn"><span className="material-symbols-outlined fill" style={{ fontSize: 16 }}>save</span>Save extractor</button>
        </div>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 22 }}>
        {/* Basic info */}
        <details open className="dx-card" style={{ padding: 0, boxShadow: '4px 4px 0 0 #000' }}>
          <summary style={{ padding: '16px 22px', display: 'flex', alignItems: 'center', gap: 10, cursor: 'pointer', borderBottom: '2px solid #000', listStyle: 'none' }}>
            <span className="material-symbols-outlined" style={{ fontSize: 22 }}>info</span>
            <span style={{ fontWeight: 900, fontSize: 15, textTransform: 'uppercase', letterSpacing: '0.05em' }}>Basic info</span>
            <span className="material-symbols-outlined" style={{ marginLeft: 'auto', fontSize: 22 }}>expand_less</span>
          </summary>
          <div style={{ padding: 22, display: 'grid', gridTemplateColumns: '1fr 280px', gap: 28 }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
              <div>
                <label style={{ fontSize: 12, fontWeight: 800, textTransform: 'uppercase', letterSpacing: '0.08em' }}>Name</label>
                <input className="dx-input" style={{ paddingLeft: 14, marginTop: 6 }} defaultValue="Invoice Auto-Processor" />
              </div>
              <div>
                <label style={{ fontSize: 12, fontWeight: 800, textTransform: 'uppercase', letterSpacing: '0.08em' }}>Description</label>
                <textarea style={{ width: '100%', minHeight: 88, padding: 14, border: '2px solid #000', boxShadow: '4px 4px 0 0 #000', marginTop: 6, fontFamily: 'inherit', fontSize: 13, resize: 'vertical' }}
                  defaultValue="Pulls vendor, line items, totals and tax IDs from PDF invoices. Tested across 1,200+ vendor formats." />
              </div>
            </div>
            <div>
              <label style={{ fontSize: 12, fontWeight: 800, textTransform: 'uppercase', letterSpacing: '0.08em' }}>Thumbnail</label>
              <div style={{ marginTop: 6, height: 180, background: '#fef3c7', border: '3px dashed #000', display: 'grid', placeItems: 'center', cursor: 'pointer' }}>
                <div style={{ textAlign: 'center', color: '#5a5440' }}>
                  <span className="material-symbols-outlined" style={{ fontSize: 38 }}>cloud_upload</span>
                  <div style={{ fontSize: 12, fontWeight: 800, marginTop: 4 }}>Drop image or click</div>
                </div>
              </div>
            </div>
          </div>
        </details>

        {/* Schema visual editor */}
        <details open className="dx-card" style={{ padding: 0, boxShadow: '4px 4px 0 0 #000' }}>
          <summary style={{ padding: '16px 22px', display: 'flex', alignItems: 'center', gap: 10, cursor: 'pointer', borderBottom: '2px solid #000', listStyle: 'none' }}>
            <span className="material-symbols-outlined" style={{ fontSize: 22 }}>schema</span>
            <span style={{ fontWeight: 900, fontSize: 15, textTransform: 'uppercase', letterSpacing: '0.05em' }}>Schema</span>
            <span style={{ marginLeft: 12, background: '#000', color: '#fff', fontSize: 10, fontWeight: 800, padding: '2px 8px', borderRadius: 999 }}>10 fields</span>
            <span className="material-symbols-outlined" style={{ marginLeft: 'auto', fontSize: 22 }}>expand_less</span>
          </summary>
          <div style={{ padding: 22 }}>
            <div style={{ display: 'flex', gap: 8, marginBottom: 14 }}>
              <button className="dx-btn outline" style={{ padding: '6px 12px' }}><span className="material-symbols-outlined" style={{ fontSize: 16 }}>add</span>Add field</button>
              <button className="dx-btn outline" style={{ padding: '6px 12px' }}><span className="material-symbols-outlined" style={{ fontSize: 16 }}>upload</span>Import JSON</button>
              <button className="dx-btn outline" style={{ padding: '6px 12px' }}><span className="material-symbols-outlined" style={{ fontSize: 16 }}>auto_awesome</span>Generate from sample</button>
            </div>
            {[
              { n: 'vendor_name', t: 'string', d: 'Legal entity name on invoice' },
              { n: 'invoice_number', t: 'string', d: 'Vendor-issued invoice number' },
              { n: 'invoice_date', t: 'date', d: 'Date the invoice was issued' },
              { n: 'subtotal', t: 'number', d: 'Pre-tax total' },
              { n: 'tax_amount', t: 'number', d: 'Total tax line' },
              { n: 'total', t: 'number', d: 'Final billable amount' },
              { n: 'currency', t: 'string', d: 'ISO 4217 currency code' },
              { n: 'line_items', t: 'array', d: 'Per-line description, qty, price, total' },
            ].map((f,i) => (
              <div key={f.n} style={{
                display: 'grid', gridTemplateColumns: '24px 1.4fr 100px 1.6fr 80px 30px',
                alignItems: 'center', gap: 12,
                padding: '10px 12px', borderBottom: '2px dashed #d6cfa6',
              }}>
                <span className="material-symbols-outlined" style={{ fontSize: 18, color: '#948a51', cursor: 'grab' }}>drag_indicator</span>
                <input style={{ padding: '8px 10px', border: '2px solid #000', fontWeight: 700, fontFamily: 'monospace' }} defaultValue={f.n} />
                <select style={{ padding: '8px 10px', border: '2px solid #000', background: f.t === 'string' ? '#dbeafe' : f.t === 'number' ? '#fef3c7' : f.t === 'date' ? '#fce7f3' : '#dcfce7', fontWeight: 800, fontSize: 12 }}>
                  <option>{f.t}</option>
                </select>
                <input style={{ padding: '8px 10px', border: '2px solid #000', fontSize: 12 }} defaultValue={f.d} />
                <label style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 11, fontWeight: 800 }}>
                  <input type="checkbox" defaultChecked={i < 4} style={{ accentColor: '#000', width: 14, height: 14 }} />
                  Req.
                </label>
                <button style={{ background: 'none', border: 'none', cursor: 'pointer' }}>
                  <span className="material-symbols-outlined" style={{ fontSize: 18, color: '#948a51' }}>delete</span>
                </button>
              </div>
            ))}
          </div>
        </details>

        {/* Advanced */}
        <details className="dx-card" style={{ padding: 0, boxShadow: '4px 4px 0 0 #000' }}>
          <summary style={{ padding: '16px 22px', display: 'flex', alignItems: 'center', gap: 10, cursor: 'pointer', listStyle: 'none' }}>
            <span className="material-symbols-outlined" style={{ fontSize: 22 }}>tune</span>
            <span style={{ fontWeight: 900, fontSize: 15, textTransform: 'uppercase', letterSpacing: '0.05em' }}>Advanced — prompt, examples, model</span>
            <span style={{ marginLeft: 12, fontSize: 11, fontWeight: 700, color: '#948a51' }}>3 sections</span>
            <span className="material-symbols-outlined" style={{ marginLeft: 'auto', fontSize: 22 }}>expand_more</span>
          </summary>
        </details>

        <div style={{ height: 60 }} />
      </div>

      {/* Bottom bar */}
      <div style={{
        position: 'sticky', bottom: -32, marginLeft: -36, marginRight: -36, marginBottom: -32,
        background: 'rgba(255,255,255,0.92)', backdropFilter: 'blur(8px)',
        borderTop: '2px solid var(--border-light)',
        padding: '14px 36px',
        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
        zIndex: 10,
      }}>
        <span style={{ fontSize: 12, fontWeight: 700, color: '#5a5440', display: 'flex', alignItems: 'center', gap: 8 }}>
          <span style={{ width: 8, height: 8, borderRadius: 999, background: '#f59e0b' }} />
          Unsaved changes
        </span>
        <button className="dx-btn" style={{ padding: '12px 24px', fontSize: 14 }}>
          <span className="material-symbols-outlined fill" style={{ fontSize: 18 }}>save</span>
          Save extractor
        </button>
      </div>
    </AppShell>
  );
}

/* ============ RUNS LIST ============ */
function RunsListScreen() {
  const runs = [
    { id: 'd4f1a2e9', name: 'Invoice Auto-Processor', when: 'Apr 21, 14:02', status: 'done', conf: 98 },
    { id: '8b1c0f33', name: 'Cash receipts', when: 'Apr 21, 13:51', status: 'review', conf: 72 },
    { id: 'a90d12bc', name: 'Bank statement parser', when: 'Apr 21, 13:24', status: 'done', conf: 99 },
    { id: 'cc40e7d1', name: 'KYC document intake', when: 'Apr 21, 12:48', status: 'failed', conf: null },
    { id: 'f1928aa7', name: 'POS daily sales', when: 'Apr 21, 12:02', status: 'done', conf: 96 },
    { id: '7263abcd', name: 'Loan application forms', when: 'Apr 21, 11:11', status: 'done', conf: 92 },
    { id: '5512cdef', name: 'Insurance claim forms', when: 'Apr 21, 10:48', status: 'review', conf: 78 },
    { id: '9844eef0', name: 'Invoice Auto-Processor', when: 'Apr 21, 10:02', status: 'done', conf: 99 },
  ];
  return (
    <AppShell active="runs">
      <PageHeader heading="Extraction Runs" description="Monitor and manage your AI extraction extractors with precision."
        breadcrumb="/ HOME / RUNS">
        <button className="dx-btn"><span className="material-symbols-outlined" style={{ fontSize: 18 }}>add_circle</span>New run</button>
      </PageHeader>

      {/* Filters */}
      <div style={{ display: 'flex', gap: 16, alignItems: 'flex-end', marginBottom: 22 }}>
        <div>
          <label style={{ fontSize: 11, fontWeight: 800, textTransform: 'uppercase', letterSpacing: '0.1em' }}>Search</label>
          <div style={{ position: 'relative', marginTop: 6, width: 280 }}>
            <span className="material-symbols-outlined" style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', fontSize: 18, color: '#888' }}>search</span>
            <input className="dx-input" placeholder="Search by Run ID…" />
          </div>
        </div>
        <div>
          <label style={{ fontSize: 11, fontWeight: 800, textTransform: 'uppercase', letterSpacing: '0.1em' }}>Extractor</label>
          <button className="dx-btn outline" style={{ marginTop: 6, padding: '10px 14px', minWidth: 180, justifyContent: 'space-between' }}>
            All extractors <span className="material-symbols-outlined" style={{ fontSize: 18 }}>expand_more</span>
          </button>
        </div>
        <div>
          <label style={{ fontSize: 11, fontWeight: 800, textTransform: 'uppercase', letterSpacing: '0.1em' }}>Status</label>
          <button className="dx-btn outline" style={{ marginTop: 6, padding: '10px 14px', minWidth: 140, justifyContent: 'space-between' }}>
            Any status <span className="material-symbols-outlined" style={{ fontSize: 18 }}>expand_more</span>
          </button>
        </div>
      </div>

      {/* Stats */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 20, marginBottom: 24 }}>
        <StatCard label="Total runs" value="1,241" icon="history" />
        <StatCard label="Successful" value="1,202" icon="check_circle" accent="var(--primary)" />
        <StatCard label="Failed" value="38" icon="warning" shadow="4px 4px 0 0 var(--accent-red)" />
      </div>

      {/* Table */}
      <div className="dx-card" style={{ padding: 0, overflow: 'hidden' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
          <thead>
            <tr style={{ background: '#f7f7f5', borderBottom: '3px solid #000' }}>
              {['Run ID','Extractor','Timestamp','Status','Confidence','Actions'].map(h => (
                <th key={h} style={{ padding: '14px 20px', textAlign: h === 'Actions' ? 'right' : 'left', fontSize: 11, fontWeight: 900, textTransform: 'uppercase', letterSpacing: '0.1em' }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {runs.map((r,i) => (
              <tr key={r.id} style={{ borderBottom: i < runs.length - 1 ? '2px solid #f0ecd4' : 'none' }}>
                <td style={{ padding: '14px 20px', fontFamily: 'monospace', fontWeight: 800, textDecoration: 'underline' }}>#{r.id}</td>
                <td style={{ padding: '14px 20px', fontWeight: 800, textTransform: 'uppercase', letterSpacing: '-0.01em' }}>{r.name}</td>
                <td style={{ padding: '14px 20px', color: '#948a51', fontWeight: 700 }}>{r.when}</td>
                <td style={{ padding: '14px 20px' }}>
                  <span className={`dx-pill ${r.status === 'done' ? 'status-success' : r.status === 'review' ? 'status-paused' : 'status-failed'}`}>{r.status}</span>
                </td>
                <td style={{ padding: '14px 20px' }}>
                  <span className={`dx-pill ${r.conf == null ? 'status-failed' : r.conf > 90 ? 'status-success' : 'status-paused'}`} style={{ minWidth: 80, justifyContent: 'center' }}>
                    <span className="material-symbols-outlined" style={{ fontSize: 12 }}>verified</span>
                    {r.conf == null ? 'N/A' : `${r.conf}%`}
                  </span>
                </td>
                <td style={{ padding: '14px 20px', textAlign: 'right' }}>
                  <div style={{ display: 'inline-flex', gap: 6 }}>
                    {['visibility','replay','delete'].map(ic => (
                      <button key={ic} style={{ width: 36, height: 36, background: '#fff', border: '2px solid #000', boxShadow: '2px 2px 0 0 #000', cursor: 'pointer' }}>
                        <span className="material-symbols-outlined" style={{ fontSize: 18 }}>{ic}</span>
                      </button>
                    ))}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 18 }}>
        <span style={{ fontSize: 11, fontWeight: 800, color: '#948a51', textTransform: 'uppercase', letterSpacing: '0.1em' }}>Showing 1–8 of 1,241 runs</span>
        <div style={{ display: 'flex', gap: 8 }}>
          <button className="dx-btn outline" style={{ padding: '8px 16px' }}><span className="material-symbols-outlined" style={{ fontSize: 16 }}>arrow_back</span>Prev</button>
          <button className="dx-btn outline" style={{ padding: '8px 16px' }}>Next<span className="material-symbols-outlined" style={{ fontSize: 16 }}>arrow_forward</span></button>
        </div>
      </div>
    </AppShell>
  );
}

Object.assign(window, { ExtractorDetailScreen, ExtractorFormScreen, RunsListScreen });
