/* Auth screens — Landing, Login, Signup, Setup, Verify, Invite */

function AuthFrame({ children, width = 480 }) {
  return (
    <div style={{
      width: 1440, height: 900,
      background: '#f0f0f0',
      backgroundImage: 'radial-gradient(#000000 1px, transparent 1px)',
      backgroundSize: '24px 24px',
      display: 'grid', placeItems: 'center',
      padding: 40,
    }}>
      <div style={{
        position: 'relative',
        width, maxWidth: '100%',
        background: '#fff',
        border: '4px solid #000',
        boxShadow: '8px 8px 0 0 #000',
        padding: '44px 48px',
      }}>
        {/* corner pegs */}
        {[[0,0],[1,0],[0,1],[1,1]].map(([x,y]) => (
          <div key={`${x}${y}`} style={{
            position: 'absolute',
            [x ? 'right' : 'left']: -10,
            [y ? 'bottom' : 'top']: -10,
            width: 18, height: 18, borderRadius: 999,
            background: '#000', border: '3px solid #fff',
          }} />
        ))}
        {children}
      </div>
    </div>
  );
}

function AuthHeader({ icon, title, subtitle, accent = 'var(--primary)' }) {
  return (
    <div style={{ textAlign: 'center', marginBottom: 30 }}>
      <div style={{
        width: 64, height: 64,
        margin: '0 auto 16px',
        background: accent,
        border: '2px solid #000',
        boxShadow: '4px 4px 0 0 #000',
        display: 'grid', placeItems: 'center',
      }}>
        <span className="material-symbols-outlined" style={{ fontSize: 34 }}>{icon}</span>
      </div>
      <h1 style={{
        margin: 0, fontSize: 26, fontWeight: 900,
        textTransform: 'uppercase', letterSpacing: '-0.02em',
      }}>{title}</h1>
      {subtitle && (
        <p style={{ margin: '8px 0 0', color: '#5a5440', fontSize: 14, fontWeight: 500 }}>{subtitle}</p>
      )}
    </div>
  );
}

function FormField({ label, icon, type = 'text', placeholder, value }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginBottom: 18 }}>
      <label style={{ fontSize: 12, fontWeight: 800, textTransform: 'uppercase', letterSpacing: '0.08em' }}>
        {label}
      </label>
      <div style={{ position: 'relative' }}>
        <span className="material-symbols-outlined" style={{
          position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)',
          fontSize: 20, color: '#888',
        }}>{icon}</span>
        <input className="dx-input" type={type} placeholder={placeholder} defaultValue={value} />
      </div>
    </div>
  );
}

/* ============ LANDING ============ */
function LandingScreen() {
  return (
    <div style={{
      width: 1440, height: 900,
      background: '#fffdf2',
      overflow: 'hidden',
      position: 'relative',
      display: 'flex', flexDirection: 'column',
    }}>
      {/* Nav */}
      <nav style={{
        height: 72, padding: '0 56px',
        display: 'flex', alignItems: 'center',
        borderBottom: '2px solid #000',
        background: '#fffdf2',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{
            width: 40, height: 40,
            background: 'var(--primary)',
            border: '2px solid #000',
            boxShadow: '3px 3px 0 0 #000',
            display: 'grid', placeItems: 'center',
            fontWeight: 900, fontStyle: 'italic', fontSize: 20,
          }}>D</div>
          <div style={{ fontSize: 20, fontWeight: 900, letterSpacing: '-0.02em' }}>docXtractor</div>
        </div>
        <div style={{ display: 'flex', gap: 32, marginLeft: 56 }}>
          {['Features', 'Templates', 'Pricing', 'Docs'].map(l => (
            <a key={l} style={{ fontSize: 14, fontWeight: 700, color: '#1a190e', textDecoration: 'none' }}>{l}</a>
          ))}
        </div>
        <div style={{ flex: 1 }} />
        <div style={{ display: 'flex', gap: 12 }}>
          <button className="dx-btn ghost" style={{ boxShadow: 'none', background: 'transparent', textTransform: 'none', padding: '8px 14px', fontWeight: 700 }}>Sign in</button>
          <button className="dx-btn">Start free</button>
        </div>
      </nav>

      {/* Hero */}
      <div style={{ flex: 1, display: 'grid', gridTemplateColumns: '1.1fr 1fr', padding: '40px 56px', gap: 48, position: 'relative' }}>
        {/* dot grid bg */}
        <div className="dot-grid" style={{ position: 'absolute', inset: 0, opacity: 0.06, pointerEvents: 'none' }} />

        <div style={{ position: 'relative', display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
          <div className="dx-pill" style={{ background: 'var(--accent-cyan)', alignSelf: 'flex-start', marginBottom: 24 }}>
            <span className="material-symbols-outlined" style={{ fontSize: 14 }}>bolt</span>
            New • AI-powered AutoRuns
          </div>
          <h1 style={{
            margin: 0, fontSize: 76, fontWeight: 900, lineHeight: 0.95,
            letterSpacing: '-0.04em',
            fontFamily: 'Archivo Black, Archivo, sans-serif',
          }}>
            Turn any<br/>document<br/>into <span style={{
              background: 'var(--primary)',
              padding: '0 14px',
              boxShadow: '6px 6px 0 0 #000',
              border: '3px solid #000',
              display: 'inline-block',
              transform: 'rotate(-2deg)',
              fontStyle: 'italic',
            }}>clean data.</span>
          </h1>
          <p style={{ marginTop: 28, fontSize: 17, lineHeight: 1.5, color: '#3d3a26', maxWidth: 480 }}>
            Built for finance teams, bankers, and operations staff — no code, no engineers. Upload invoices, receipts, statements; get back the spreadsheet you actually need.
          </p>

          <div style={{ marginTop: 36, display: 'flex', gap: 14 }}>
            <button className="dx-btn" style={{ padding: '16px 28px', fontSize: 14 }}>
              Try a sample doc
              <span className="material-symbols-outlined">arrow_forward</span>
            </button>
            <button className="dx-btn outline" style={{ padding: '16px 28px', fontSize: 14 }}>
              Watch 90s demo
            </button>
          </div>

          <div style={{ marginTop: 40, display: 'flex', gap: 32, alignItems: 'center' }}>
            <div>
              <div style={{ fontSize: 28, fontWeight: 900, letterSpacing: '-0.02em' }}>4.2k+</div>
              <div style={{ fontSize: 11, fontWeight: 700, color: '#948a51', textTransform: 'uppercase', letterSpacing: '0.1em' }}>Docs / day</div>
            </div>
            <div style={{ width: 1, height: 36, background: '#000' }} />
            <div>
              <div style={{ fontSize: 28, fontWeight: 900, letterSpacing: '-0.02em' }}>99.4%</div>
              <div style={{ fontSize: 11, fontWeight: 700, color: '#948a51', textTransform: 'uppercase', letterSpacing: '0.1em' }}>Accuracy</div>
            </div>
            <div style={{ width: 1, height: 36, background: '#000' }} />
            <div>
              <div style={{ fontSize: 28, fontWeight: 900, letterSpacing: '-0.02em' }}>SOC2</div>
              <div style={{ fontSize: 11, fontWeight: 700, color: '#948a51', textTransform: 'uppercase', letterSpacing: '0.1em' }}>Type II</div>
            </div>
          </div>
        </div>

        {/* Hero illustration — sample doc → spreadsheet */}
        <div style={{ position: 'relative', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          {/* PDF card */}
          <div style={{
            position: 'absolute', left: 0, top: 60,
            width: 280, height: 360,
            background: '#fff', border: '3px solid #000',
            boxShadow: '8px 8px 0 0 #000',
            padding: '16px 20px',
            transform: 'rotate(-4deg)',
          }}>
            <div style={{ fontSize: 9, fontWeight: 800, color: '#948a51', letterSpacing: '0.15em' }}>INVOICE • 2025-0421</div>
            <div style={{ fontSize: 22, fontWeight: 900, marginTop: 8, letterSpacing: '-0.02em' }}>Acme Corp.</div>
            <div style={{ fontSize: 10, color: '#5a5440', marginTop: 4 }}>1234 Industrial Way • Dhaka</div>
            <div style={{ height: 2, background: '#000', margin: '14px 0' }} />
            {[
              ['Audit retainer', '12,500.00'],
              ['Compliance review', '4,800.00'],
              ['Documentation', '1,200.00'],
              ['Express handling', '450.00'],
            ].map(([l,v],i) => (
              <div key={i} style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 0', borderBottom: '1px dashed #ccc', fontSize: 11 }}>
                <span style={{ fontWeight: 600 }}>{l}</span>
                <span style={{ fontFamily: 'monospace', fontWeight: 700 }}>{v}</span>
              </div>
            ))}
            <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 14, padding: '8px 10px', background: 'var(--primary)', border: '2px solid #000' }}>
              <span style={{ fontSize: 11, fontWeight: 900, textTransform: 'uppercase' }}>Total</span>
              <span style={{ fontFamily: 'monospace', fontWeight: 900, fontSize: 13 }}>$18,950.00</span>
            </div>
          </div>

          {/* Arrow */}
          <div style={{
            position: 'absolute', left: 280, top: 200,
            zIndex: 5,
            width: 70, height: 70,
            background: 'var(--accent-cyan)',
            border: '3px solid #000',
            boxShadow: '4px 4px 0 0 #000',
            borderRadius: 999,
            display: 'grid', placeItems: 'center',
            transform: 'rotate(15deg)',
          }}>
            <span className="material-symbols-outlined" style={{ fontSize: 36, fontWeight: 900 }}>arrow_forward</span>
          </div>

          {/* Spreadsheet card */}
          <div style={{
            position: 'absolute', right: 0, top: 80,
            width: 320, height: 320,
            background: '#fff', border: '3px solid #000',
            boxShadow: '8px 8px 0 0 #000',
            transform: 'rotate(3deg)',
            overflow: 'hidden',
          }}>
            <div style={{
              background: '#000', color: 'var(--accent-green)',
              padding: '8px 14px', fontSize: 10, fontWeight: 800, letterSpacing: '0.15em',
              fontFamily: 'monospace',
            }}>extracted_data.json</div>
            <div style={{ display: 'grid', gridTemplateColumns: '1.2fr 1fr', fontSize: 11 }}>
              {['Field','Value','vendor','Acme Corp.','invoice','2025-0421','date','2025-04-21','total','$18,950.00','currency','USD','line_items','4 rows','tax_id','12-3456789'].map((c,i) => {
                const isHeader = i < 2;
                return (
                  <div key={i} style={{
                    padding: '9px 12px',
                    borderRight: i % 2 === 0 ? '2px solid #000' : 'none',
                    borderBottom: '2px solid #000',
                    background: isHeader ? '#000' : i % 4 < 2 ? '#fff' : '#f7f7f5',
                    color: isHeader ? '#fff' : '#000',
                    fontFamily: i % 2 === 1 && !isHeader ? 'monospace' : 'inherit',
                    fontWeight: isHeader ? 900 : i % 2 === 0 ? 700 : 600,
                    textTransform: isHeader ? 'uppercase' : 'none',
                    letterSpacing: isHeader ? '0.1em' : 0,
                    fontSize: isHeader ? 10 : 12,
                  }}>{c}</div>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* Bottom logo bar */}
      <div style={{
        height: 80, borderTop: '2px solid #000',
        background: '#000', color: '#fff',
        display: 'flex', alignItems: 'center', padding: '0 56px', gap: 36,
      }}>
        <div style={{ fontSize: 11, fontWeight: 800, color: 'var(--primary)', textTransform: 'uppercase', letterSpacing: '0.15em' }}>
          Trusted by teams at
        </div>
        {['Eastern Bank', 'BRAC IT', 'Robi Axiata', 'Pathao Pay', 'IDLC Finance', 'Square Group'].map(name => (
          <div key={name} style={{ fontSize: 17, fontWeight: 800, fontStyle: 'italic', opacity: 0.85 }}>{name}</div>
        ))}
      </div>
    </div>
  );
}

/* ============ LOGIN ============ */
function LoginScreen() {
  return (
    <AuthFrame>
      <AuthHeader icon="login" title="Welcome back" subtitle="Sign in to continue extracting." />
      <FormField label="Email" icon="mail" type="email" placeholder="you@example.com" value="salman@cefalo.com" />
      <FormField label="Password" icon="lock" type="password" placeholder="••••••••" value="opensesame" />
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', margin: '6px 0 18px' }}>
        <label style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 12, fontWeight: 700 }}>
          <input type="checkbox" defaultChecked style={{ accentColor: '#000', width: 16, height: 16 }} />
          Remember me
        </label>
        <a style={{ fontSize: 12, fontWeight: 700, color: '#1a190e', textDecoration: 'underline' }}>Forgot password?</a>
      </div>
      <button className="dx-btn" style={{ width: '100%', justifyContent: 'center', padding: '14px 0', fontSize: 14 }}>
        Sign in
        <span className="material-symbols-outlined">arrow_forward</span>
      </button>

      <div style={{ display: 'flex', alignItems: 'center', gap: 12, margin: '24px 0' }}>
        <div style={{ flex: 1, height: 2, background: '#000' }} />
        <span style={{ fontSize: 11, fontWeight: 800, letterSpacing: '0.15em', color: '#948a51' }}>OR</span>
        <div style={{ flex: 1, height: 2, background: '#000' }} />
      </div>

      <button className="dx-btn outline" style={{ width: '100%', justifyContent: 'center', padding: '12px 0', fontSize: 13 }}>
        <span className="material-symbols-outlined">link</span>
        Email me a magic link
      </button>

      <p style={{ textAlign: 'center', marginTop: 24, fontSize: 13, color: '#5a5440' }}>
        New here? <a style={{ fontWeight: 800, color: '#000', textDecoration: 'underline' }}>Create an account</a>
      </p>
    </AuthFrame>
  );
}

/* ============ SIGNUP ============ */
function SignupScreen() {
  return (
    <AuthFrame>
      <AuthHeader icon="person_add" title="Create account" subtitle="Free for the first 100 documents." accent="var(--accent-cyan)" />
      <FormField label="Full name" icon="badge" placeholder="Jane Doe" value="Salman Ahmed" />
      <FormField label="Work email" icon="mail" type="email" placeholder="you@company.com" value="salman@cefalo.com" />
      <FormField label="Password" icon="lock" type="password" placeholder="At least 8 characters" value="opensesame" />

      <div style={{
        background: '#f7f7f5', border: '2px solid #000',
        padding: 12, marginBottom: 18, fontSize: 11, fontWeight: 700,
      }}>
        <div style={{ display: 'flex', gap: 6, marginBottom: 6 }}>
          {[1,1,1,0].map((on,i) => (
            <div key={i} style={{ flex: 1, height: 6, background: on ? 'var(--accent-cyan)' : '#ddd', border: '1px solid #000' }} />
          ))}
        </div>
        <span style={{ color: '#5a5440' }}>Strong — 12 chars, mixed case, 1 symbol</span>
      </div>

      <label style={{ display: 'flex', gap: 10, fontSize: 12, fontWeight: 600, marginBottom: 18, color: '#3d3a26' }}>
        <input type="checkbox" defaultChecked style={{ accentColor: '#000', width: 16, height: 16, marginTop: 2 }} />
        <span>I agree to the <a style={{ color: '#000', fontWeight: 800, textDecoration: 'underline' }}>Terms</a> and <a style={{ color: '#000', fontWeight: 800, textDecoration: 'underline' }}>Privacy Policy</a>.</span>
      </label>

      <button className="dx-btn" style={{ width: '100%', justifyContent: 'center', padding: '14px 0', fontSize: 14 }}>
        Create account
        <span className="material-symbols-outlined">how_to_reg</span>
      </button>

      <p style={{ textAlign: 'center', marginTop: 22, fontSize: 13, color: '#5a5440' }}>
        Already have one? <a style={{ fontWeight: 800, color: '#000', textDecoration: 'underline' }}>Sign in</a>
      </p>
    </AuthFrame>
  );
}

/* ============ SETUP — first-run instance setup ============ */
function SetupScreen() {
  return (
    <AuthFrame width={560}>
      <AuthHeader icon="rocket_launch" title="Set up Docxtractor" subtitle="One-time setup for this instance. You'll be the admin." />

      <div style={{
        background: 'var(--primary)', border: '2px solid #000',
        padding: '12px 14px', marginBottom: 24,
        display: 'flex', gap: 10, alignItems: 'center',
        fontSize: 12, fontWeight: 700,
      }}>
        <span className="material-symbols-outlined">info</span>
        This is the first user. After this, new accounts are invite-only.
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
        <FormField label="First name" icon="badge" value="Salman" />
        <FormField label="Last name" icon="badge" value="Ahmed" />
      </div>
      <FormField label="Admin email" icon="mail" value="salman@cefalo.com" />
      <FormField label="Password" icon="lock" type="password" value="opensesame" />

      <div style={{
        marginTop: 8, padding: '14px 16px',
        background: '#f7f7f5', border: '2px solid #000',
        marginBottom: 22,
      }}>
        <div style={{ fontSize: 11, fontWeight: 800, textTransform: 'uppercase', letterSpacing: '0.1em', marginBottom: 10 }}>
          Default LLM provider
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 8 }}>
          {[
            { name: 'OpenAI', model: 'gpt-4o', selected: true },
            { name: 'Anthropic', model: 'claude-3.5', selected: false },
            { name: 'Local', model: 'ollama', selected: false },
          ].map(p => (
            <div key={p.name} style={{
              padding: '12px 10px',
              border: '2px solid #000',
              background: p.selected ? 'var(--accent-cyan)' : '#fff',
              boxShadow: p.selected ? '4px 4px 0 0 #000' : '2px 2px 0 0 #000',
              cursor: 'pointer',
              textAlign: 'center',
            }}>
              <div style={{ fontWeight: 900, fontSize: 13 }}>{p.name}</div>
              <div style={{ fontSize: 10, fontFamily: 'monospace', color: '#5a5440', marginTop: 2 }}>{p.model}</div>
            </div>
          ))}
        </div>
      </div>

      <button className="dx-btn" style={{ width: '100%', justifyContent: 'center', padding: '14px 0', fontSize: 14 }}>
        Finish setup
        <span className="material-symbols-outlined">check</span>
      </button>
    </AuthFrame>
  );
}

/* ============ VERIFY — magic link landing ============ */
function VerifyScreen() {
  return (
    <AuthFrame width={440}>
      <AuthHeader icon="check_circle" title="Email verified" subtitle="Redirecting you to your dashboard…" accent="#86efac" />
      <div style={{
        background: '#f0fdf4', border: '2px solid #000',
        padding: 16,
        display: 'flex', alignItems: 'center', gap: 12,
        fontSize: 13, fontWeight: 700,
      }}>
        <div style={{
          width: 28, height: 28, border: '3px solid #000',
          borderTopColor: 'transparent', borderRadius: 999,
          animation: 'spin 1s linear infinite',
        }} />
        Logging you in as <span style={{ fontFamily: 'monospace' }}>salman@cefalo.com</span>
      </div>
      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </AuthFrame>
  );
}

/* ============ INVITE ACCEPT ============ */
function InviteScreen() {
  return (
    <AuthFrame width={480}>
      <AuthHeader icon="person_add" title="Accept invite" subtitle="You've been invited to join Cefalo workspace as Editor." accent="#fdba74" />

      <div style={{
        background: '#fef3c7', border: '2px solid #000',
        padding: '12px 14px', marginBottom: 22,
        display: 'flex', gap: 10, alignItems: 'center', fontSize: 12, fontWeight: 700,
      }}>
        <span className="material-symbols-outlined" style={{ fontSize: 18 }}>schedule</span>
        Invite expires in 47 hours.
      </div>

      <FormField label="Email (locked)" icon="mail" value="rina@cefalo.com" />
      <FormField label="Choose password" icon="lock" type="password" value="opensesame" />
      <FormField label="Confirm password" icon="lock" type="password" value="opensesame" />

      <button className="dx-btn" style={{ width: '100%', justifyContent: 'center', padding: '14px 0', fontSize: 14, marginTop: 8 }}>
        Join workspace
        <span className="material-symbols-outlined">how_to_reg</span>
      </button>
    </AuthFrame>
  );
}

Object.assign(window, { LoginScreen, SignupScreen, SetupScreen, VerifyScreen, InviteScreen });
